/************************************************************
 *
 * RelCheck
 *
 * version 0.67, 8/24/2000
 *
 * copyright (C) 2000 Karl W. Broman, Johns Hopkins University
 * Licensed under the GNU General Public License version 2 (June, 1991)
 *
 * References:
 *
 * Boehnke M, Cox NJ, Am J Hum Genet 61:423-9, 1997
 * Broman KW, Weber JL, Am J Hum Genet 63:1563-1564, 1998
 *
 * See "relcheck.h" or "ReadMe.txt" for information about 
 * using the program 
 *
 ************************************************************
 * This file: "relcheck_io.c"
 **********************************************************************/

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "relcheck.h"

/**************************************
 *
 * loadParam
 *
 *    Load data on marker/map information:
 *
 *        n_chr
 *        n_mar dist1 dist2 dist3 ...
 *        n_alle freq1 freq2 freq3...
 *
 **************************************/

void loadParam(char *mapfile, int *n_chr, int **n_mar, double ***dist,
	       int ***n_alle, double ****freq)
{
  FILE *fp;
  int i, j, k;
  double loc = 0.0;

  if((fp=fopen(mapfile, "r"))==NULL) {
    printf("Cannot open file %s\n", mapfile);
    exit(1);
  }
  fscanf(fp, "%ld", n_chr);

  /* allocate some memory */
  *n_mar = (int *)malloc(sizeof(int) * *n_chr);
  *dist = (double **)malloc(sizeof(double *) * *n_chr);
  *n_alle = (int **)malloc(sizeof(int *) * *n_chr);
  *freq = (double ***)malloc(sizeof(double **) * *n_chr);
  if(*n_mar == NULL || *dist == NULL || *n_alle == NULL || *freq == NULL) {
    printf("Cannot allocate memory for %ld chromosomes\n", *n_chr);
    exit(1);
  }

  printf(" ---No. chromosomes: %ld\n", *n_chr);
  printf(" ---No. markers:");
  for(i=0; i < *n_chr; i++) {
    fscanf(fp, "%ld", &((*n_mar)[i]));
    printf(" %ld", (*n_mar)[i]);

    /* allocate some more memory */
    (*dist)[i] = (double *)malloc(sizeof(double) * ((*n_mar)[i] - 1));
    (*n_alle)[i] = (int *)malloc(sizeof(int) * (*n_mar)[i]);
    (*freq)[i] = (double **)malloc(sizeof(double *) * (*n_mar)[i]);
    if((*dist)[i] == NULL || (*n_alle)[i] == NULL || (*freq)[i] == NULL) {
      printf("Cannot allocate memory for %ld markers on chr %ld\n",
	     (*n_mar)[i], i+1);
      exit(1);
    }

    for(j=1; j < (*n_mar)[i]; j++) {
      fscanf(fp, "%lf", &loc);
      loc = exp(loc/25.0);
      (*dist)[i][j-1] = 0.5*(loc-1.0)/(loc+1.0); /* Kosambi */
      if((*dist)[i][j-1] < MINR) (*dist)[i][j-1] = MINR;
    }

    for(j=0; j < (*n_mar)[i]; j++) {
      fscanf(fp, "%ld", &((*n_alle)[i][j]));

      /* allocate some more memory */
      (*freq)[i][j] = (double *)malloc(sizeof(double) * (*n_alle)[i][j]);
      if((*freq)[i][j] == NULL) {
	printf("Cannot allocate mem for %ld alle. for mar. %ld on chr %ld\n",
	       (*n_alle)[i][j], (*n_mar)[i], i+1);
	exit(1);
      }

      for(k=0; k < (*n_alle)[i][j]; k++) {
	fscanf(fp, "%lf", &((*freq)[i][j][k]));
	if((*freq)[i][j][k] < 0.00001) printf(" ***  %lf\n", (*freq)[i][j][k]);
      }
    }
  }

  printf("\n");
  fclose(fp);

}





/**************************************
 *
 * loadGenotypes
 *
 *    Load genotype data
 *
 *    (sex: 0=female; 1=male)
 *
 *    n_fam
 *    n_mar
 *    fam1
 *    n_ind
 *    ind1 mom1 dad1 sex1
 *    g11 g12 g21 g22 ...
 *    ...
 *
 **************************************/

void loadGenotypes(char *genfile, int n_chr, int *n_mar, int **n_alle,
		   int *n_fam, int **fam, int **n_ind, int ***ind, 
		   int ***flag, int *****g1, int *****g2, 
		   int ***mom, int ***dad)
{
  FILE *fp;
  int i, j, k, m;
  int sex, tot_mar;

  if((fp=fopen(genfile, "r"))==NULL) {
    printf("Cannot open file %s\n", genfile);
    exit(1);
  }
  fscanf(fp, "%ld", n_fam);
  fscanf(fp, "%ld", &tot_mar); /* not used */

  printf(" ---No. families: %ld\n", *n_fam);
  printf(" ---Families:");

  /* allocate some memory */
  *fam = (int *)malloc(sizeof(int) * *n_fam);
  *n_ind = (int *)malloc(sizeof(int) * *n_fam);
  *ind = (int **)malloc(sizeof(int *) * *n_fam);
  *mom = (int **)malloc(sizeof(int *) * *n_fam);
  *dad = (int **)malloc(sizeof(int *) * *n_fam);
  *flag = (int **)malloc(sizeof(int *) * *n_fam);
  *g1 = (int ****)malloc(sizeof(int ***) * *n_fam);
  *g2 = (int ****)malloc(sizeof(int ***) * *n_fam);
  if(*fam == NULL || *n_ind == NULL || *ind == NULL ||
     *flag == NULL || *g1 == NULL || *g2 == NULL || 
     *mom == NULL || *dad == NULL) {
    printf("Cannot allocate memory for %ld families\n", *n_fam);
    exit(1);
  }

  for(i=0; i < *n_fam; i++) {

    fscanf(fp, "%ld", &((*fam)[i]));
    fscanf(fp, "%ld", &((*n_ind)[i]));

    printf(" %ld", (*fam)[i]);

    /* allocate some memory */
    (*ind)[i] = (int *)malloc(sizeof(int) * (*n_ind)[i]);
    (*mom)[i] = (int *)malloc(sizeof(int) * (*n_ind)[i]);
    (*dad)[i] = (int *)malloc(sizeof(int) * (*n_ind)[i]);
    (*flag)[i] = (int *)malloc(sizeof(int) * (*n_ind)[i]);
    (*g1)[i] = (int ***)malloc(sizeof(int **) * (*n_ind)[i]);
    (*g2)[i] = (int ***)malloc(sizeof(int **) * (*n_ind)[i]);

    if((*ind)[i] == NULL || (*flag)[i] == NULL || (*g1)[i] == NULL ||
       (*g2)[i] == NULL || (*mom)[i] == NULL || (*dad)[i] == NULL) {
      printf("Cannot allocate memory for %ld individuals in family %ld\n",
	     (*n_ind)[i], i+1);
      exit(1);
    }
    for(j=0; j < (*n_ind)[i]; j++) {
      fscanf(fp, "%ld", &((*ind)[i][j]));
      fscanf(fp, "%ld", &((*mom)[i][j]));
      fscanf(fp, "%ld", &((*dad)[i][j]));
      fscanf(fp, "%ld", &sex); /* not used */
      (*flag)[i][j] = 0;

      /* allocate some memory */
      (*g1)[i][j] = (int **)malloc(sizeof(int *) * n_chr);
      (*g2)[i][j] = (int **) malloc(sizeof(int *) * n_chr);
      if((*g1)[i][j] == NULL || (*g2)[i][j] == NULL) {
	printf("Cannot allocate memory for %ld chromosomes\n", n_chr);
	exit(1);
      }

      for(k=0; k< n_chr; k++) {
	/* allocate some memory */
	(*g1)[i][j][k] = (int *)malloc(sizeof(int)*n_mar[k]);
	(*g2)[i][j][k] = (int *)malloc(sizeof(int)*n_mar[k]);
	if((*g1)[i][j][k] == NULL || (*g2)[i][j][k] == NULL) {
	  printf("Cannot allocate memory for %ld markers\n", n_mar[k]);
	  exit(1);
	}

	for(m=0; m<n_mar[k]; m++) {
	  fscanf(fp, "%ld", &((*g1)[i][j][k][m]));
	  fscanf(fp, "%ld", &((*g2)[i][j][k][m]));
	  if((*g1)[i][j][k][m] != 0 || (*g2)[i][j][k][m] != 0) {
	    (*flag)[i][j] = 1;
	  }
	  if((*g1)[i][j][k][m] > n_alle[k][m] || (*g2)[i][j][k][m] > n_alle[k][m]) {
	    printf(" ::ERR:: Individual %d in family %d has genotype %d:%d at marker %d:%d\n",
		   (*ind)[i][j], (*fam)[i], (*g1)[i][j][k][m], (*g2)[i][j][k][m], 
		   k+1, m+1);
	    printf("         but the no. alleles is %d\n", n_alle[k][m]);
	  }
	      
	}
      }
    }
  }
  printf("\n");
  fclose(fp);
}

/* end of relcheck_io.c */
