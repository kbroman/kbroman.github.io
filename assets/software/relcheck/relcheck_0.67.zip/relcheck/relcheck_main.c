/************************************************************
 *
 * RelCheck
 *
 * version 0.67, 8/24/2000
 *
 * copyright (C) 2000 Karl W. Broman, Johns Hopkins University
 * Licensed under the GNU General Public License version 2 (June, 1991)
 *
 * References:
 *
 * Boehnke M, Cox NJ, Am J Hum Genet 61:423-9, 1997
 * Broman KW, Weber JL, Am J Hum Genet 63:1563-1564, 1998
 *
 * See "relcheck.h" or "ReadMe.txt" for information about 
 * using the program 
 *
 ************************************************************
 * This file: "relcheck_main.c"
 **********************************************************************/

/**********************************************************************
 * 
 * Note for those that have looked this far:
 *
 * This code is not my best work, but it runs, gives the right answers, 
 * and I don't really want to re-write the whole thing.
 *
 * If you have any suggestions, or if you would like to work with me
 * to improve things, I'd be very glad to hear from you.
 *
 **********************************************************************/

#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include "relcheck.h"

int main(int argc, char *argv[])
{
  char genfile[80], mapfile[80], outfile[80];
  int n_chr, *n_mar, **n_alle, n_fam, *fam, *n_ind, **ind, **flag;
  int **mom, **dad, ibs[3], n_typed;
  double **dist, ***freq;
  int ****g1, ****g2;
  FILE *fp;
  int i, j, i2, j2, s, k;
  char relationships[6][40];
  double llr[5], max_llr;
  int max_rel, put_rel;
  int verbose=0;
  int do_all=0;
  double err=0.01;

  /* get command-line arguments */
  if(argc > 1) {
    err = atof(argv[1]);
  }
  if(argc > 2) {
    do_all = atoi(argv[2]);
  }
  
  err *= 2.0;

  /* fill in relationship names */
  strcpy(relationships[0], "MZ twins");
  strcpy(relationships[1], "parent/offspring");
  strcpy(relationships[2], "full sibs");
  strcpy(relationships[3], "half sibs");
  strcpy(relationships[4], "unrelated");
  strcpy(relationships[5], "other");

  /* get file names */
  strcpy(genfile, "relcheck.gen");
  strcpy(mapfile, "relcheck.map");
  strcpy(outfile, "relcheck_out.csv");

  printf("-----------------------\n");
  printf("    RelCheck\n");
  printf("    Version 0.67\n");
  printf("    24 August 2000\n");
  printf("    Karl Broman\n");
  printf("-----------------------\n");
  printf(" -Loading marker/map information from %s\n", mapfile);
  loadParam(mapfile, &n_chr, &n_mar, &dist, &n_alle, &freq);

  printf(" -Loading genotype information from %s\n", genfile);
  loadGenotypes(genfile,n_chr,n_mar,n_alle,&n_fam,&fam,&n_ind,&ind,&flag,
		&g1,&g2,&mom, &dad);

  printf(" -Calculating probabilities and writing to %s\n", outfile);
  printf(" ---Using err = %lf\n", err/2.0);
  if(do_all) printf(" ---Comparing all pairs\n");
  else printf(" ---Comparing pairs within families\n");

  if((fp=fopen(outfile,"w"))==NULL) {
    printf("Cannot write to %s\n", outfile);
    exit(1);
  }

  fprintf(fp, ",,,,putative,inferred,,IBS,,,LOD,LOD,LOD,LOD,LOD\n");
  fprintf(fp, "fam1,ind1,fam2,ind2,relationship,relationship,0,1,2,");
  fprintf(fp, "n_typed,MZtwins,par/off,fullsibs,halfsibs,unrelated\n\n");

  if(!do_all) { /* do only within families */

    /* loop through all individuals */
    for(i=0; i<n_fam; i++) {

      printf(" ---Family %4d out of %4d\n", i+1, n_fam);
      for(j=0; j<n_ind[i]-1; j++) {
	if(flag[i][j] == 1) { /* does indiv have genotype data? */

	  /* loop through all later individ. in that family */
	  for(j2=j+1; j2<n_ind[i]; j2++) {
	    if(flag[i][j2] == 1) { /* does indiv have genotype data? */

	      /* calculate IBS */
	      calcIBS(n_chr, n_mar, &n_typed, ibs,
		      g1[i][j], g2[i][j], g1[i][j2], g2[i][j2]);

	      if(n_typed > MINTYPED) { 
		/* if less than MINTYPED markers are typed, don't go on to 
		   do the likelihood stuff, and don't print out anything */

		/* calculate LLR for each relationship */
		calcLLR(n_chr, n_mar, dist, n_alle, freq, g1[i][j], g2[i][j],
			g1[i][j2], g2[i][j2], llr, err);

		/* determine ML relationship */
		llr[4] = 0.0;
		max_rel = 0;
		llr[0] /= LOG10; /* rescale to log base 10 */
		max_llr = llr[0];
		for(s=1; s<4; s++) {
		  llr[s] /= LOG10; /* rescale to log base 10 */
		  if(llr[s] > max_llr) {
		    max_llr = llr[s];
		    max_rel = s;
		  }
		}
		if(llr[4] > max_llr) {
		  max_llr = llr[4];
		  max_rel = 4;
		}

	      /* print results */
		fprintf(fp, "%d,%d,%d,%d,", fam[i], ind[i][j], fam[i], ind[i][j2]);
	      
		/* determine putative relationship */
		if(mom[i][j]==mom[i][j2] && dad[i][j]==dad[i][j2] &&
		   mom[i][j] != 0 && dad[i][j]!=0) 
		  put_rel = 2; /* full sib */
		else if((mom[i][j]==mom[i][j2] && mom[i][j]!=0) || 
			(dad[i][j]==dad[i][j2] && dad[i][j]!=0))
		  put_rel = 3; /* half sib */
		else if(mom[i][j]==ind[i][j2] || dad[i][j]==ind[i][j2] ||
			mom[i][j2]==ind[i][j] || dad[i][j2]==ind[i][j])
		  put_rel = 1; /* par/off */
		else if(mom[i][j]==0 && dad[i][j]==0 &&
			mom[i][j2]==0 && dad[i][j2]==0) 
		  put_rel = 4; /* unrelated */
		else
		  put_rel = 5; /* other */
		
		/* print putative and inferred relationships */
		fprintf(fp, "%s,%s,", relationships[put_rel],relationships[max_rel]);

		/* print IBS data */
		fprintf(fp, "%d,%d,%d,%d,", ibs[0], ibs[1], ibs[2], n_typed);

		/* print LOD scores relative to inferred relationship */
		for(s=0; s<5; s++) 
		  fprintf(fp, "%.2lf,", llr[s] - max_llr);
	      
		/* print <<<< if putative relationship looks wrong */
		if(put_rel != 5 && max_llr-llr[put_rel] > THRESH) 
		  fprintf(fp, "<<<<");

		fprintf(fp, "\n");
	      }

	    } /* if(flag[i][j2]==1) i.e. data on individual */
	  } /* loop over second individual */
	} /* if(flag[i][j]==1) i.e. data on individual */
      } /* loop over first individual */
      fprintf(fp, "\n");
    } /* loop over families */
  }

  else { /* do all pairs of individuals */

    /* loop through all individuals */
    for(i=0; i<n_fam; i++) {
      printf(" ---Family %4d out of %4d\n", i+1, n_fam);
      for(j=0; j<n_ind[i]; j++) {
	if(flag[i][j] == 1) { /* does indiv have genotype data? */
	  /* loop through all later individ. */
	  for(i2=i; i2<n_fam; i2++) {
	    for(j2=0; j2<n_ind[i2]; j2++) {
	      if(flag[i2][j2] == 1 && (i2 != i || j2 > j)) {
		/* does indiv have genotype data? */
		/* also, is it really a "later" individual? */

		/* calculate IBS */
		calcIBS(n_chr, n_mar, &n_typed, ibs,
			g1[i][j], g2[i][j], g1[i2][j2], g2[i2][j2]);

		if(n_typed > MINTYPED) {
		  /* if less than MINTYPED markers are typed, don't go on to 
		     do the likelihood stuff, and don't print out anything */

		  /* calculate LLR for each relationship */
		  calcLLR(n_chr, n_mar, dist, n_alle, freq, g1[i][j], g2[i][j],
			  g1[i2][j2], g2[i2][j2], llr, err);

		  /* determine ML relationship */
		  llr[4] = 0.0;
		  llr[0] /= LOG10; /* rescale to log base 10 */
		  max_rel = 0;
		  max_llr = llr[0];
		  for(s=1; s<4; s++) {
		    llr[s] /= LOG10; /* rescale to log base 10 */
		    if(llr[s] > max_llr) {
		      max_rel = s;
		      max_llr = llr[s];
		    }
		  }
		  if(llr[4] > max_llr) {
		    max_llr = llr[4];
		    max_rel = 4;
		  }

		  /* print results */
		  fprintf(fp, "%d,%d,%d,%d,", fam[i], ind[i][j], fam[i2], ind[i2][j2]);
		  
		  /* determine putative relationship */
		  if(fam[i] == fam[i2]) {
		    if(mom[i][j]==mom[i2][j2] && dad[i][j]==dad[i2][j2] &&
		       mom[i][j] != 0 && dad[i][j]!=0) 
		      put_rel = 2; /* full sib */
		    else if((mom[i][j]==mom[i2][j2] && mom[i][j]!=0) || 
			    (dad[i][j]==dad[i2][j2] && dad[i][j]!=0))
		      put_rel = 3; /* half sib */
		    else if(mom[i][j]==ind[i2][j2] || dad[i][j]==ind[i2][j2] ||
			    mom[i2][j2]==ind[i][j] || dad[i2][j2]==ind[i][j])
		      put_rel = 1; /* par/off */
		    else if(mom[i][j]==0 && dad[i][j]==0 &&
			    mom[i2][j2]==0 && dad[i2][j2]==0) 
		      put_rel = 4; /* unrelated */
		    else
		      put_rel = 5; /* other */
		  }
		  else put_rel = 4;

		  /* print putative and inferred relationships */
		  fprintf(fp, "%s,%s,", relationships[put_rel],relationships[max_rel]);
		
		  /* print IBS data */
		  fprintf(fp, "%d,%d,%d,%d,", ibs[0], ibs[1], ibs[2], n_typed);
		
		  /* print LOD scores relative to inferred relationship */
		  for(s=0; s<5; s++) 
		    fprintf(fp, "%.2lf,", llr[s] - max_llr);
	      
		  /* print <<<< if putative relationship looks wrong */
		  if(put_rel != 5 && max_llr-llr[put_rel] > THRESH) 
		    fprintf(fp, "<<<<");
		  
		  fprintf(fp, "\n");
		}

	      } /* if(flag[i2][j2]==1) i.e. data on individual */
	    } /* loop over second individual */
	  } /* loop over second family */
	} /* if(flag[i][j]==1) i.e. data on individual */
      } /* loop over first individual */
      fprintf(fp, "\n");
    } /* loop over families */
  }

  fclose(fp);


  printf(" -Freeing memory\n\n");
  /* free memory */
  for(i=0; i< n_fam; i++) {
    for(j=0; j< n_ind[i]; j++) {
      for(k=0; k<n_chr; k++) {
	free(g1[i][j][k]);
	free(g2[i][j][k]);
      }
      free(g1[i][j]);
      free(g2[i][j]);
    }
    free(g1[i]);
    free(g2[i]);
    free(ind[i]);
    free(mom[i]);
    free(dad[i]);
    free(flag[i]);
  }
  free(fam);
  free(n_ind);
  free(g1);
  free(g2);
  free(ind);
  free(mom);
  free(dad);
  free(flag);

  for(i=0; i<n_chr; i++) {
    for(j=0; j<n_mar[i]; j++) {
      free(freq[i][j]);
    }
    free(freq[i]);
    free(n_alle[i]);
    free(dist[i]);
  }
  free(freq);
  free(n_alle);
  free(dist);
  free(n_mar);

  return(0); /* done! */

}


/* end of relcheck_main.c */
