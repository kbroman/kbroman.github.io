/************************************************************
 *
 * RelCheck
 *
 * version 0.67, 8/24/2000
 *
 * copyright (C) 2000 Karl W. Broman, Johns Hopkins University
 * Licensed under the GNU General Public License version 2 (June, 1991)
 *
 * References:
 *
 * Boehnke M, Cox NJ, Am J Hum Genet 61:423-9, 1997
 * Broman KW, Weber JL, Am J Hum Genet 63:1563-1564, 1998
 *
 * See "relcheck.h" or "ReadMe.txt" for information about 
 * using the program 
 *
 ************************************************************
 * This file: "relcheck_util.c"
 **********************************************************************/
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "relcheck.h"


/*********************************************************
 *
 *   calcLLR
 *
 *   calculation the log likelihood for each of the five
 *   relationships
 *
 *********************************************************/

void calcLLR(int n_chr, int *n_mar, double **dist, int **n_alle,
	     double ***freq, int **g11, int **g12, int **g21,
	     int **g22, double *llr, double err)
{
  int i, j, k;
  double px0, px1, px2;
  double step00, step01, step10, step11;
  double ahs0=0.0, ahs1=0.0;
  double afs00=0.0, afs10=0.0, afs11=0.0;
  double psi, step0, step1, step2;
  double temp1, temp2;

  for(k=0; k<4; k++) llr[k] = 0.0;

  for(i=0; i<n_chr; i++) {
    for(j=0; j<n_mar[i]; j++) {

      /* calculate Pr(X|IBD = i)
      if(g11[i][j] > n_alle[i][j] ||
	 g12[i][j] > n_alle[i][j] ||
	 g21[i][j] > n_alle[i][j] ||
	 g22[i][j] > n_alle[i][j]) {
	printf("%d %d %d %d %d\n", g11[i][j], g12[i][j], g21[i][j],
	       g22[i][j], n_alle[i][j]);
      } */

      calcPrX(g11[i][j], g12[i][j], g21[i][j], g22[i][j], freq[i][j],
	      &px0, &px1, &px2, err);

      /* calculate LLR for twins, parent/offspring */
      llr[0] += (px2 - px0);  /* twins */
      llr[1] += (px1 - px0);  /* parent-offspring */

      /* initial alphas */
      if(j==0) {
	/* full sibs */
	afs00 = afs10 = afs11 = log(0.25);
	afs10 += (px1-px0); afs11 += (px2-px0);

	/* other rels */
	ahs0 = ahs1 = log(0.5);  ahs1 += (px1-px0);
      }
      else {
	/* full sibs */
	psi = (1.0-dist[i][j-1]);
	psi = psi*psi + dist[i][j-1]*dist[i][j-1];
	step0 = psi*psi;
	step1 = psi*(1.0-psi);
	step2 = (1.0-psi)*(1.0-psi);
	temp1 = log(step0 + 2.0*step1*exp(afs10-afs00) +
		    step2*exp(afs11-afs00));
	temp2 = (px1-px0) + log(step0 + step2 +
				step1*(exp(afs00-afs10) + exp(afs11-afs10)));
	afs11 += (px2-px0) + log(step0 + step2*exp(afs00-afs11) +
				 2.0*step1*exp(afs10-afs11));
	afs00 += temp1; afs10 += temp2;

	/* half sibs */
	/* calculate Pr(IBD_j = i | IBD_j-1 = j) */
	step00 = step11 = psi;
	step10 = step01 = 1.0 - step11;

	temp1 = log(step00 + step10*exp(ahs1-ahs0));
	ahs1 += (px1-px0) + log(step11 + step01*exp(ahs0-ahs1));
	ahs0 += temp1;

      }
    }

    llr[2] += afs00 + log(1.0 + 2.0*exp(afs10-afs00) + exp(afs11-afs00));

    llr[3] += ahs0 + log(1.0 + exp(ahs1-ahs0));

  } /* loop over chromosomes */

} /* end of function */






/**********************************************************************
 * 
 * calcPrX
 * 
 * calculates Pr(genotype X | IBD = k)
 *
 **********************************************************************/

void calcPrX(int g11, int g12, int g21, int g22, double *freq,
	     double *px0, double *px1, double *px2, double err)
{
  double temp;

  /* deter. px0 = Pr(genotypes X | IBD = 0) and pr(genotypes X | IBD = 1) */
  if(g11 == 0 || g12 == 0) {
    if(g21 == 0 || g22 == 0) { /* all data missing */
      *px0 = *px1 = *px2 = 1.0;
    }
    else {
      *px0 = *px1 = *px2 = 1.0;
    }
  }
  else {
    if(g21 == 0 || g22 == 0) {
      *px0 = *px1 = *px2 = 1.0;
    }
    else {
      if(g11 == g12) {
	if(g11 == g21) {
	  if(g11 == g22) { /* AA AA */
	    *px2 = freq[g11-1]*freq[g11-1];
	    *px1 = *px2 * freq[g11-1];
	    *px0 = *px1 * freq[g11-1];
	  }
	  else { /* AA AB */
	    *px0 = *px1 = freq[g11-1]*freq[g11-1]*freq[g22-1];
	    *px0 *= (2.0 * freq[g11-1]);
	    *px2 = 0.0;
	  }
	}
	else {
	  if(g11 == g22) { /* AA BA */
	    *px0 = *px1 = freq[g11-1]*freq[g11-1]*freq[g21-1];
	    *px0 *= (2.0 * freq[g11-1]);
	    *px2 = 0.0;
	  }
	  else if(g21 == g22) { /* AA BB */
	    *px2 = *px1 = 0.0;
	    *px0 = freq[g11-1] * freq[g21-1];
	    *px0 *= *px0;
	  }
	  else { /* AA BC */
	    *px2 = *px1 = 0.0;
	    *px0 = 2.0*freq[g11-1]*freq[g11-1]*freq[g21-1]*freq[g22-1];
	  }
	}
      }
      else {
	if(g11 == g21) {
	  if(g11 == g22) { /* AB AA */
	    *px0 = *px1 = freq[g11-1]*freq[g11-1]*freq[g12-1];
	    *px0 *= (2.0 * freq[g11-1]);
	    *px2 = 0.0;
	  }
	  else if(g12 == g22) { /* AB AB */
	    *px2 = *px0 = *px1 = freq[g11-1]*freq[g12-1];
	    *px2 *= 2.0;
	    *px0 *= (4.0 * *px0);
	    *px1 *= (freq[g11-1] + freq[g12-1]);
	  }
	  else { /* AB AC */
	    *px0 = *px1 = freq[g11-1]*freq[g12-1]*freq[g22-1];
	    *px0 *= (4.0 * freq[g11-1]);
	    *px2 = 0.0;
	  }
	}
	else {
	  if(g12 == g21) {
	    if(g11 == g22) { /* AB BA */
	      *px2 = *px0 = *px1 = freq[g11-1]*freq[g21-1];
	      *px2 *= 2.0;
	      *px0 *= (4.0 * *px0);
	      *px1 *= (freq[g11-1] + freq[g21-1]);
	    }
	    else if(g12 == g22) { /* AB BB */
	      *px0=*px1=freq[g21-1]*freq[g21-1]*freq[g11-1];
	      *px0 *= (2.0 * freq[g21-1]);
	      *px2 = 0.0;
	    }
	    else { /* AB BC */
	      *px0=*px1=freq[g11-1]*freq[g12-1]*freq[g22-1];
	      *px0 *= (4.0 * freq[g12-1]);
	      *px2 = 0.0;
	    }
	  }
	  else {
	    if(g11 == g22) { /* AB CA */
	      *px0=*px1=freq[g11-1]*freq[g12-1]*freq[g21-1];
	      *px0 *= (4.0 * freq[g11-1]);
	      *px2 = 0.0;
	    }
	    else if(g12 == g22) { /* AB CB */
	      *px0=*px1=freq[g11-1]*freq[g12-1]*freq[g21-1];
	      *px0 *= (4.0 * freq[g12-1]);
	      *px2 = 0.0;
	    }
	    else if(g21 == g22) { /* AB CC */
	      *px2 = *px1 = 0.0;
	      *px0 = 2.0*freq[g11-1]*freq[g12-1]*freq[g21-1]*freq[g21-1];
	    }
	    else { /* AB CD */
	      *px2 = *px1 = 0.0;
	      *px0 = freq[g11-1]*freq[g12-1];
	      *px0 *= (4.0*freq[g21-1]*freq[g22-1]);

	    }
	  }
	}
      } /* end of if/else statements */

      /* dealing with errors */
      temp = *px1*(1.0-err) + *px0*err;
      *px2 = log(*px2*(1.0-err) + *px0*err);
      *px1 = log(temp);
      *px0 = log(*px0);
    }
  }
}


/* calculate IBS */
void calcIBS(int n_chr, int *n_mar, int *n_typed, int ibs[3], 
	     int **g11, int **g12, int **g21, int **g22)
{
  int i, j;

  *n_typed = ibs[0] = ibs[1] = ibs[2] = 0;

  for(i=0; i<n_chr; i++) {
    for(j=0; j<n_mar[i]; j++) {
      if(g11[i][j]!=0 && g12[i][j]!=0 &&
	 g21[i][j]!=0 && g22[i][j]!=0) { /* typed */
	(*n_typed)++;
	
	if((g11[i][j]==g21[i][j] && g12[i][j]==g22[i][j]) ||
	   (g11[i][j]==g22[i][j] && g12[i][j]==g21[i][j]))  /* ibs=2 */
	  ibs[2]++;
	else if(g11[i][j]==g21[i][j] || g11[i][j]==g22[i][j] ||
		g12[i][j]==g21[i][j] || g12[i][j]==g22[i][j]) /* ibs=1 */
	  ibs[1]++;

	else ibs[0]++;
      }

    }
  }
}
	  
  




/* end of relcheck_util.c */

