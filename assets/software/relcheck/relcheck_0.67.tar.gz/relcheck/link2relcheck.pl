#!/usr/local/bin/perl
######################################################################
#
# link2relcheck.pl
#
# version 0.7
#
# copyright (C) 2000 Karl W. Broman, Johns Hopkins University
# Licensed under the GNU General Public License version 2 (June, 1991)
#
# 7 June 2000 
#
#     Change from version 0.6: fixed bug where spaces at the beginning
#                                  of lines screwed things up
#                              also, check that nos of map distances 
#                                  is correct
#
# Convert genotype and map information into files suitable for
# use with my RelCheck program
#
# The input files should be stem*.pre and stem*.dat where 
#     "stem" = to be given as a command-line argument
#     *      = 1, 2, ..., 22
#     
# For example, if your files are chr1.pre, chr1.dat, ..., then type:
#     link2relcheck.pl chr
#
######################################################################

(@ARGV > 0) or die("Give input stem\n");
$stem = $ARGV[0];
$mapout = "relcheck.map";
$genout = "relcheck.gen";

print(" -Reading maps and allele frequencies\n");
$totmar = 0;
foreach $chr (1..22) {
    $ifile = "$stem$chr" . ".dat";
    if(!open(IN, $ifile))  { next; }
    $line = <IN>; chomp($line);
    @v = split(/\s+/, $line);
    if($v[0] eq "") { shift @v; }
    $nmar = $v[0] - 1;
    $totmar += $nmar;
    foreach $i (1..6) { $line = <IN>; }
    foreach $i (1..$nmar) {
	$line = <IN>;
	$line = <IN>; chomp($line);
	@v = split(/\s+/, $line);
	if($v[0] eq "") { shift @v; }
	@{$freq{$chr}{$i}} = @v;
    }
    $line = <IN>;
    $line = <IN>; chomp($line);
    @v = split(/\s+/, $line);
    if($v[0] eq "") { shift @v; }
    $lenv = @v;
    if($lenv > $nmar-1) { shift @v; }
    @{$dist{$chr}} = @v;
    close(IN);
}
print(" ---Total no. markers: $totmar\n");

open(OUT, ">$mapout") or die("Cannot write to $mapout");
print OUT ("22\n");
foreach $chr (1..22) {
    $nmar = @{$dist{$chr}} + 1;
    print OUT ("$nmar ", join(" ", @{$dist{$chr}}), "\n");
    foreach $i (sort numerically keys %{$freq{$chr}}) {
	$nalle = @{$freq{$chr}{$i}};
	print OUT ("$nalle ", join(" ", @{$freq{$chr}{$i}}), "\n");
    }
}
close(OUT);

print(" -Reading genotype data\n");
foreach $chr (1..22) {
    $ifile = "$stem$chr" . ".pre";
    if(!open(IN, $ifile)) { next; }
    while($line = <IN>) {
	chomp($line);
	@v = split(/\s+/, $line);
	if($v[0] eq "") { shift @v; }
	($fam,$ind,$dad,$mom,$sex,$phe,@gen) = @v;
	$dad{$fam}{$ind} = $dad;
	$mom{$fam}{$ind} = $mom;
	$sex{$fam}{$ind} = $sex;
	if($sex{$fam}{$ind} == 2) { $sex{$fam}{$ind} = 0; }
	if($chr == 1) {
	    @{$gen{$fam}{$ind}} = @gen;
	}
	else { 
	    @{$gen{$fam}{$ind}} = (@{$gen{$fam}{$ind}}, @gen);
	}
	    
    }
    close(IN);
}


open(OUT, ">$genout") or die("Cannot write to $genout");
$nfam = keys %mom;
print OUT ("$nfam\n$totmar\n");
foreach $fam (sort numerically keys %mom) {
    print OUT ("$fam\n");
    $nind = keys %{$mom{$fam}};
    print OUT ("$nind\n");
    foreach $ind (sort numerically keys %{$mom{$fam}}) {
	print OUT ("$ind $mom{$fam}{$ind} $dad{$fam}{$ind} $sex{$fam}{$ind}\n");
	print OUT (join(" ", @{$gen{$fam}{$ind}}), "\n");
	$temp_nmar = @{$gen{$fam}{$ind}}/2;
	if($temp_nmar != $totmar) { 
	    print("$fam $ind $temp_nmar\n");
	    $problem = 1;
	    @problems = ($fam, $ind, $temp_nmar, $totmar);
	}
    }
}
close(OUT);

if($problem==1) {
    print(join(" ", @problems), "\n");
    print(" --Potential problem:\n");
    print(" ----No. markers in map files: $totmar\n");
    print(" ----Individual $problems[0]-$problems[1] has genotypes for $problems[2] markers\n");
    print(" ----(Other individuals may also be problematic\n\n");
}

    



sub numerically { $a <=> $b; }




