/**********************************************************************
 *
 * f2_io.c
 *
 * copyright (C) 2000 Karl W. Broman, Johns Hopkins University
 * Licensed under the GNU General Public License version 2 (June, 1991)
 *
 * January, 2000; August, 1998 
 *
 *    This is part of the program "F2," whose aim is to provide a
 * method for using forward selection to identify multiple QTLs
 * segregating in an F2-intercross.
 *
 *    This part of the program does the input of the map, marker and
 * genetic data, and allocates and frees memory for those things.
 *
 **********************************************************************
 *
 * Functions:
 *
 *     load_map
 *     free_map
 *     load_data
 *     free_data
 *
 **********************************************************************/

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "f2.h"

/**********************************************************************
 * load_map: loads map information
 *
 * map file should be in the following form: (thetas = recomb. fracs
 *
 * n_chr
 * n_mar1 theta1 theta2 ... theta(n_mar1-1)
 * marker_name1
 * marker_name2
 * ...
 * marker_name(n_mar1)
 * n_mar2 theta1 theta2 ... theta(n_mar2-1)
 * ...
 **********************************************************************/
void load_map(char *file, int *n_chr, int **n_mar, int *max_n_mar,
	      double ***theta, double ***alpha, double ***beta,
	      char ****marker_names)
{
  int i, j;
  FILE *fp;

  /* open file */
  if(!(fp=fopen(file, "r"))) {
    printf("Cannot read from %s in load_map\n", file);
    exit(1);
  }

  fscanf(fp, "%d", n_chr);

  *n_mar = (int *)malloc(sizeof(int)*(*n_chr));
  *theta = (double **)malloc(sizeof(double *)*(*n_chr));
  *marker_names = (char ***)malloc(sizeof(char **)*(*n_chr));
  if(!(*n_mar) || !(*theta) || !(*marker_names)) {
    printf("Cannot allocate enough memory in load_map (1)\n");
    exit(1);
  }
  *max_n_mar = 0;

  for(i=0; i<(*n_chr); i++) {
    fscanf(fp, "%d", *n_mar+i);
    if((*n_mar)[i] > *max_n_mar) *max_n_mar = (*n_mar)[i];

    (*theta)[i] = (double *)malloc(sizeof(double)*((*n_mar)[i]-1));
    (*marker_names)[i] = (char **)malloc(sizeof(char*)*(*n_mar)[i]);
    if(!((*theta)[i]) || !((*marker_names)[i])) {
      printf("Cannot allocate enough memory in load_map (2-%d)\n", i);
      exit(1);
    }
    (*marker_names)[i][0] = (char *)malloc(sizeof(char)*(*n_mar)[i]*30);
    if(!((*marker_names)[i][0])) {
      printf("Cannot allocate enough memory in load_map (2b)\n");
      exit(1);
    }
    for(j=0; j < (*n_mar)[i]-1; j++)
      fscanf(fp, "%lf", (*theta)[i] + j);
    for(j=0; j < (*n_mar)[i]; j++) {
      (*marker_names)[i][j] = (*marker_names)[i][0]+j*30;
      fscanf(fp, "%s", (*marker_names)[i][j]);
    }

  }

  *alpha = (double **)malloc(sizeof(double *)*4);
  *beta = (double **)malloc(sizeof(double *)*4);
  if(!(*alpha) || !(*beta)) {
    printf("Cannot allocate enough memory in load_map (3)\n");
    exit(1);
  }
  for(i=0; i<4; i++) {
    (*alpha)[i] = (double *)malloc(sizeof(double)*(*max_n_mar));
    (*beta)[i] = (double *)malloc(sizeof(double)*(*max_n_mar));
    if(!((*alpha)[i]) || !((*beta)[i])) {
      printf("Cannot allocate enough memory in load_map (4-%d)\n", i);
      exit(1);
    }
  }

  fclose(fp);
}



/**********************************************************************
 * free_map : free memory for map
 **********************************************************************/
void free_map(int n_chr, int *n_mar, double **theta,
	      double **alpha, double **beta, 
	      char ***marker_names)
{
  int i;

  for(i=0; i<n_chr; i++) {
    free(theta[i]);
    free(marker_names[i][0]);
    free(marker_names[i]);
  }

  for(i=0; i<4; i++) {
    free(alpha[i]);
    free(beta[i]);
  }

  free(marker_names);
  free(alpha);
  free(beta);
  free(theta);
  free(n_mar);

}




/**********************************************************************
 * load_data: loads phenotype and genotype data
 *
 * genotype data file should be in the following form:
 *
 * n_ind
 * gen11 gen12 gen13 ...
 * gen21 gen22 gen23 ...
 * ...
 *
 * phenotype data file should be in the following form:
 * [ - or NA for missing values ]
 *
 * n_ind
 * phen1
 * phen2
 * ...
 **********************************************************************/
void load_data(char *genfile, char *phefile, int n_chr, int *n_mar,
	       int *n_ind, double **y, int ****g)
{
  int i, j, k, *missing, temp_nind=0, i2, i3;
  FILE *fpg, *fpp;
  char temp[80];

  /* open files */
  if(!(fpg=fopen(genfile, "r"))) {
    printf("Cannot read from %s in load_data\n", genfile);
    exit(1);
  }
  if(!(fpp=fopen(phefile, "r"))) {
    printf("Cannot read from %s in load_data\n", phefile);
    exit(1);
  }

  fscanf(fpg, "%d", n_ind);
  fscanf(fpp, "%d", &i);
  if(i != *n_ind) {
    printf("number of individuals in %s and %s don't match\n", genfile, phefile);
    exit(1);
  }

  *y = (double *)malloc(sizeof(double)*(*n_ind));
  missing = (int *)malloc(sizeof(int)*(*n_ind));
  if(!(*y) || !missing) {
    printf("Cannot allocate enough memory in load_data (0)\n");
    printf("%2d\n", (*n_ind));
    exit(1);
  }
  /* read phenotypes; drop individuals with missing values */
  for(i=0, j=0; i< *n_ind; i++) {
    fscanf(fpp, "%s", temp);
    if(!strcmp(temp, "-") || !strcmp(temp, "NA")) {
      missing[i] = 1;
    }
    else {
      temp_nind++;
      (*y)[j] = atof(temp);
      j++;
      missing[i] = 0;
    }
  }

  *g = (int ***)malloc(sizeof(int **)*temp_nind);
  if(!(*g)) {
    printf("Cannot allocate enough memory in load_data (1)\n");
    exit(1);
  }

  /* allocate memory for genotypes */
  for(i=0; i< temp_nind; i++) {
    (*g)[i] = (int **)malloc(sizeof(int *)*n_chr);
    if(!((*g)[i])) {
      printf("Cannot allocate enough memory in load_data (2-%d)\n", i);
      exit(1);
    }
    for(j=0; j<n_chr; j++) {
      (*g)[i][j] = (int *)malloc(sizeof(int)*n_mar[j]);
      if(!((*g)[i][j])) {
	printf("Cannot allocate enough memory in load_data (3-%d,%d)\n", i, j);
	exit(1);
      }
    }
  }

  for(i=0,i2=0; i<(*n_ind); i++) {
    if(missing[i]) {
      for(j=0; j<n_chr; j++) {
	for(k=0; k<n_mar[j]; k++) {
	  fscanf(fpg, "%d", &i3);
	}
      }
    }
    else {
      for(j=0; j<n_chr; j++) {
	for(k=0; k<n_mar[j]; k++) {
	  fscanf(fpg, "%d", (*g)[i2][j] + k);
	}
      }
      i2++;
    }
  }

  *n_ind = temp_nind;

  fclose(fpg);
  fclose(fpp);
}


/**********************************************************************
 * free_data : free memory for phenotypes and genotypes
 **********************************************************************/
void free_data(int n_ind, int n_chr, int *n_mar, double *y, int ***g)
{
  int i, j;

  for(i=0; i<n_ind; i++) {
    for(j=0; j<n_chr; j++) {
      free(g[i][j]);
    }
    free(g[i]);
  }
  free(g);
  free(y);
}


/* end of f2_io.c */

