/**********************************************************************
 *
 * f2_lg.c
 *
 * copyright (C) 2000 Karl W. Broman, Johns Hopkins University
 * Licensed under the GNU General Public License version 2 (June, 1991)
 *
 * January, 2000; August, 1998 
 *
 *    This is part of the program "F2," whose aim is to provide a
 * method for using forward selection to identify multiple QTLs
 * segregating in an F2-intercross.
 *
 *    This part of the program uses a Lander-Green-type algorithm,
 * the forward/backward algorithms for HMMs, to calculate, for a
 * single individual, Pr(AA|x) and Pr(BB|x) where x is the set of
 * genetic data on a chromosome.
 *
 **********************************************************************

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "f2.h"

/**********************************************************************
 * hmm: this program uses the Lander-green algorithm to calculate
 *      Pr(AA at k|x) and Pr(BB at k|x) at each locus k
 **********************************************************************/
void hmm(int n_mar, double *theta, int *g, double *p, double *q,
	 double **alpha, double **beta)
{
  int i, j, k;
  double s;
  double emit(int, int);
  double step(int, int, double);

  /* initialize alphas and beta */
  for(i=0; i<4; i++) {
    alpha[i][0] = 0.25 * emit(g[0], i);
    beta[i][n_mar-1] = 1.0;
  }

  /* Lander-Green algorithm */
  for(k=1; k<n_mar; k++) {

    for(i=0; i<4; i++) {

      /* next alpha : forward eqns */
      /* prev beta : backward eqns */
      alpha[i][k] = alpha[0][k-1]*step(0,i,theta[k-1]);

      beta[i][n_mar-1-k] = beta[0][n_mar-k] * step(i,0,theta[n_mar-1-k]) *
	emit(g[n_mar-k],0);

      for(j=1; j<4; j++) {
	alpha[i][k] += alpha[j][k-1]*step(j,i,theta[k-1]);

	beta[i][n_mar-1-k] += beta[j][n_mar-k] * step(i,j,theta[n_mar-1-k]) *
	  emit(g[n_mar-k],j);

      }

      alpha[i][k] *= emit(g[k],i);
    }

  } /* loop over markers */

  /* calculate p[k], q[k] */

  for(k=0; k<n_mar; k++) {
    s = alpha[1][k]*beta[1][k] + alpha[2][k]*beta[2][k];
    s += (p[k] = alpha[0][k]*beta[0][k]);
    s += (q[k] = alpha[3][k]*beta[3][k]);

    p[k] /= s;
    q[k] /= s;
  }

}


/**********************************************************************
 * emit calculates Pr(observe genotype g | true genotype is i)
 **********************************************************************/
double emit(int g, int i)
{
  switch(g) {
  case 0: /* missing */
    return(1.0);
  case 1: /* AA */
    switch(i) {
    case 0: return(1.0); /* AA */
    case 1: return(0.0); /* AB */
    case 2: return(0.0); /* BA */
    case 3: return(0.0); /* BB */
    }
  case 2: /* AB */
    switch(i) {
    case 0: return(0.0); /* AA */
    case 1: return(1.0); /* AB */
    case 2: return(1.0); /* BA */
    case 3: return(0.0); /* BB */
    }
  case 3: /* BB */
    switch(i) {
    case 0: return(0.0); /* AA */
    case 1: return(0.0); /* AB */
    case 2: return(0.0); /* BA */
    case 3: return(1.0); /* BB */
    }
  case 4: /* not BB (i.e., either AA or AB) */
    switch(i) {
    case 0: return(1.0); /* AA */
    case 1: return(1.0); /* AB */
    case 2: return(1.0); /* BA */
    case 3: return(0.0); /* BB */
    }
  case 5: /* not AA (i.e., either AB or BB) */
    switch(i) {
    case 0: return(0.0); /* AA */
    case 1: return(1.0); /* AB */
    case 2: return(1.0); /* BA */
    case 3: return(1.0); /* BB */
    }
  }
  /* shouldn't get here */
  return(-1.0);
}


/**********************************************************************
 * step: calculates Pr(gen at k+1 is j | gen at k is i)
 **********************************************************************/
double step(int i, int j, double theta)
{
  switch(i) {
  case 0:
    switch(j) {
    case 0: return((1.0-theta)*(1.0-theta));
    case 1: case 2: return(theta*(1.0-theta));
    case 3: return(theta*theta);
    }
  case 1:
    switch(j) {
    case 0: case 3: return(theta*(1.0-theta));
    case 1: return((1.0-theta)*(1.0-theta));
    case 2: return(theta*theta);
    }
  case 2:
    switch(j) {
    case 0: case 3: return(theta*(1.0-theta));
    case 2: return((1.0-theta)*(1.0-theta));
    case 1: return(theta*theta);
    }
  case 3:
    switch(j) {
    case 3: return((1.0-theta)*(1.0-theta));
    case 1: case 2: return(theta*(1.0-theta));
    case 0: return(theta*theta);
    }
  }

  /* shouldn't get here */
  return(-1.0); 
}


/**********************************************************************
 * lg: this program uses the Lander-green algorithm to re-estimate
 *     the recombination fractions
 **********************************************************************/
void lg(int n_mar, double *theta, int *g, double *exprec,
	double **alpha, double **beta)
{
  int i, j, k;
  double s, t, gamma[4][4];
  double nrec(int, int);

  /* initialize alphas and beta */
  for(i=0; i<4; i++) {
    alpha[i][0] = 0.25 * emit(g[0], i);
    beta[i][n_mar-1] = 1.0;
  }

  /* Forward and backward equations */
  for(k=1; k<n_mar; k++) {

    for(i=0; i<4; i++) {

      /* next alpha : forward eqns */
      /* prev beta : backward eqns */
      alpha[i][k] = alpha[0][k-1]*step(0,i,theta[k-1]);

      beta[i][n_mar-1-k] = beta[0][n_mar-k] * step(i,0,theta[n_mar-1-k]) *
	emit(g[n_mar-k],0);

      for(j=1; j<4; j++) {
	alpha[i][k] += alpha[j][k-1]*step(j,i,theta[k-1]);

	beta[i][n_mar-1-k] += beta[j][n_mar-k] * step(i,j,theta[n_mar-1-k]) *
	  emit(g[n_mar-k],j);

      }

      alpha[i][k] *= emit(g[k],i);
    }

  } /* loop over markers */


  for(k=0, t=0; k<n_mar-1; k++) {
    for(i=0, s=0; i<4; i++) s += alpha[i][k];
    /* calculate gamma(i,j) = Pr(i at k, j at k+1 | x) */
    for(i=0; i<4; i++) {
      for(j=0; j<4; j++) {
	t += (gamma[i][j] = alpha[i][k]/s * step(i,j,theta[k])*beta[j][k+1]*
	      emit(g[k+1],j));
      }
    }

    exprec[k] = 0.0;
    for(i=0; i<4; i++) {
      for(j=0; j<4; j++) {
	exprec[k] += gamma[i][j]*nrec(i,j)/t;
      }
    }

  }

}

/**********************************************************************
 * calculates number of recombinations between states i and j
 * where i,j = 0 (AA), 1 (AB), 2 (BA), or 3 (BB)
 **********************************************************************/
double nrec(int i, int j)
{
  if(i==j) return(0.0);
  if(i==1 || i == 2) {
    if(j==0 || j==3) return(1.0);
    else return(2.0);
  }
  else {
    if(j==1 || j==2) return(1.0);
    else return(2.0);
  }
}



/* end of f2_lg.c */

