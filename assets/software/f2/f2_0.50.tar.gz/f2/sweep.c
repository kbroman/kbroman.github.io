/**********************************************************************
 * sweep.c
 *
 * copyright (C) 2000 Karl W. Broman, Johns Hopkins University
 * Licensed under the GNU General Public License version 2 (June, 1991)
 *
 * December 1993 and August 1998
 *
 **********************************************************************/

#include <math.h>
#include <stdlib.h>
#include "sweep.h"


/**********************************************************************
 *
 *      This function "sweeps" the columns of the matrix
 *  "matrix" which are listed in the vector "index".
 *  <size> is the # of rows in <matrix>.  <len> is the
 *  length of <index>.
 *
 *      The indices are in 0, 1, 2, ..., size - 1.
 *
 *      If the matrix is of the form (X y)'(X y), then sweeping the
 *  columns i_1, i_2, ..., i_k regresses y on X_(i_1), ..., X_(i_k).
 *  After doing that, matrix[size-1][size-1] contains the RSS and
 *  matrix[i_j][size-1] contains the est'd coefficient for X_(i_j).
 *
 *      Re-sweeping those columns reverses the process and restores
 *  the matrix to its original form.
 *
 *      Be careful of zero "pivots," which generally results from
 *  having a ill-formed matrix, of less than full rank.
 *
 **********************************************************************/

void sweep(double **matrix, int size, int *index, int len, int *err)
{
  long i, j, k;
  double b, d;

  *err=0;
  for(k=0; k<len; k++) {
    d=matrix[index[k]][index[k]];
    if(fabs(d)<=ZERO) {
      *err=1;
      return;
    }
    for(i=0; i<size; i++) matrix[index[k]][i] /= d;
    for(i=0; i<size; i++) {
      if(i!=index[k]) {
        b=matrix[i][index[k]];
        for(j=0; j<size; j++)
          matrix[i][j] -= (b*matrix[index[k]][j]);
        matrix[i][index[k]] = -b/d;
      }
    }
    matrix[index[k]][index[k]] = 1./d;
  }
}



/* end of sweep.c */
