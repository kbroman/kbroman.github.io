
README.txt:	this file



INPUT data:

 phe.txt	phenotypes
 gen.txt	genotypes
 map.txt	genetic map



OUTPUT data:

 anova.csv	anova option
 dat.csv	dat option
 forward.csv	forward option
 inter.csv	inter option
 newmap.txt	map option
