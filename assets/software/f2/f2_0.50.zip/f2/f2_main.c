/**********************************************************************
 *
 * f2_main.c
 *
 * copyright (C) 2000 Karl W. Broman, Johns Hopkins University
 * Licensed under the GNU General Public License version 2 (June, 1991)
 *
 * January, 2000; August, 1998 
 *
 *    This is the program "F2," whose aim is to provide a method for 
 * using forward selection to identify multiple QTLs segregating in an 
 * F2-intercross.
 *
 **********************************************************************/

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "f2.h"
#include "sweep.h"

int main(int argc, char *argv[])
{
  int i, j, k, n, i1, j1, i2, j2, k1, k2;
  int n_chr, *n_mar, max_n_mar, n_ind, tot_mar;
  double **theta, **newtheta, *exprec;
  double ***p, ***q, **alpha, **beta, *y, maxdiff, diff, **xpx, **x;
  int ***g;
  char mapfile[80], genfile[80], phefile[80], outfile[80], lastarg[80];
  FILE *fp;
  double rss0, mean0, mean, a, d, rss;
  int index[2], err, max_step;
  double delta;
  int *index_inter, *index_c1, *index_m1, *index_c2, *index_m2, *index_work;
  int **flag;
  char ***marker_names;

  if(argc < 6) {
    printf("Give mapfile, genfile, phefile and outfile as ");
    printf("command-line arguments\nAs 5th argument give ");
    printf("either 'est' 'dat' 'anova' 'pairs' 'inter' or\n");
    printf("    the number of markers to include by forward selection\n");
    exit(1);
  }
  strcpy(mapfile, argv[1]);
  strcpy(genfile, argv[2]);
  strcpy(phefile, argv[3]);
  strcpy(outfile, argv[4]);
  strcpy(lastarg, argv[5]);

  /* fifth argument should be either "est", "dat", "anova", "pairs" "inter" or
     the maximum number of markers to include by forward selection */

  printf(" -Reading map from %s\n", mapfile);
  load_map(mapfile, &n_chr, &n_mar, &max_n_mar, &theta, &alpha, &beta, &marker_names);
  for(i=0, tot_mar = 0; i<n_chr; i++) tot_mar += n_mar[i];

  printf(" -Reading genotype data from %s and phenotype data from %s\n",
	 genfile, phefile);
  load_data(genfile, phefile, n_chr, n_mar, &n_ind, &y, &g);
  printf(" --Number of individuals with phenotypes: %d\n", n_ind);

  /* re-estimate recombination fractions */
  if(!strcmp(lastarg, "est")) {
    allocate_lg(n_chr, n_mar, max_n_mar, &newtheta, &exprec);

    if(!(fp=fopen(outfile, "w"))) {
      printf("Cannot write to %s\n", outfile);
      exit(1);
    }

    printf(" -Estimating recombination fractions :: ");
    for(n=0; n<100; n++) {
      printf("%d ", n+1);

      for(j=0; j<n_chr; j++)
	for(k=0; k<n_mar[j]-1; k++)
	  newtheta[j][k] = 0.0;

      /* run lander-green step to estimate the expected # recombs */
      for(i=0; i<n_ind; i++) {
	for(j=0; j<n_chr; j++) {
	  lg(n_mar[j], theta[j], g[i][j], exprec, alpha, beta);
	  for(k=0; k<n_mar[j]-1; k++)
	    newtheta[j][k] += exprec[k];
	}
      }

      /* re-estimate r.f.'s and calculate change in theta */
      maxdiff = 0.0;
      for(j=0; j<n_chr; j++) {
	for(k=0; k<n_mar[j]-1; k++) {
	  newtheta[j][k] /= (double)(n_ind*2);
	  diff = fabs(newtheta[j][k] - theta[j][k]);
	  theta[j][k] = newtheta[j][k];
	  if(diff > maxdiff) maxdiff = diff;
	}
      }

      if(maxdiff < 1e-5) break;
    }
    printf("\n");

    free_lg(n_chr, newtheta, exprec);

    printf(" -Writing map\n");
    fprintf(fp, "%d\n", n_chr);
    for(i=0; i<n_chr; i++) {
      fprintf(fp, "%d ", n_mar[i]);
      for(j=0; j<n_mar[i]-1; j++) {
	if(theta[i][j] > 0.0001) fprintf(fp, "%.4lf ", theta[i][j]);
	else fprintf(fp, "%.4lf ", 0.0001);
      }
      fprintf(fp, "\n");
      for(j=0; j<n_mar[i]; j++) 
	fprintf(fp, "%s\n", marker_names[i][j]);
    }
    fclose(fp);
  }

  /* print out (X y) data */
  else if(!strcmp(lastarg, "dat")) {

    if(!(fp=fopen(outfile, "w"))) {
      printf("Cannot write to %s\n", outfile);
      exit(1);
    }

    allocate_hmm(n_ind, n_chr, n_mar, &p, &q);
    allocate_xpx(tot_mar, &xpx);

    printf(" -Running forward/backward equations\n");
    for(i=0; i<n_ind; i++)
      for(j=0; j<n_chr; j++)
	hmm(n_mar[j], theta[j], g[i][j], p[i][j], q[i][j], alpha, beta);

    printf(" -Writing data\n");
    fprintf(fp, "phenotype");
    for(j=0; j<n_chr; j++)
      for(k=0; k<n_mar[j]; k++)
	fprintf(fp, ",a.%s,d.%s",marker_names[j][k],marker_names[j][k]);
    fprintf(fp, "\n");
    for(i=0; i<n_ind; i++) {
      fprintf(fp, "%lf", y[i]);
      for(j=0; j<n_chr; j++)
	for(k=0; k<n_mar[j]; k++)
	  fprintf(fp, ",%lf,%lf", p[i][j][k]-q[i][j][k],
		  1.0-p[i][j][k]-q[i][j][k]);
      fprintf(fp, "\n");
    }

    free_hmm(n_ind, n_chr, p, q);
    free_xpx(tot_mar, xpx);
    fclose(fp);
  }

  /* anova */
  else if(!strcmp(lastarg, "anova")) {

    if(!(fp=fopen(outfile, "w"))) {
      printf("Cannot write to %s\n", outfile);
      exit(1);
    }

    allocate_hmm(n_ind, n_chr, n_mar, &p, &q);
    allocate_xpx(tot_mar, &xpx);

    printf(" -Running forward/backward equations\n");
    for(i=0; i<n_ind; i++)
      for(j=0; j<n_chr; j++)
	hmm(n_mar[j], theta[j], g[i][j], p[i][j], q[i][j], alpha, beta);


    printf(" -Creating (X y)'(X y) matrix\n");
    /* create (X y)' (X y) matrix */
    create_xpx(n_chr, n_mar, tot_mar, n_ind, p, q, y, xpx);

    printf(" -Sweeping one marker at a time");
    index[0] = 0;
    sweep(xpx, tot_mar*2+2, index, 1, &err);
    if(err) {
      printf("Error in first sweep\n");
      exit(1);
    }
    rss0 = xpx[tot_mar*2+1][tot_mar*2+1];
    mean0 = xpx[0][tot_mar*2+1];
    fprintf(fp, "chr,mar,name,LOD,RSS,mean,sigma,a,d\n");
    fprintf(fp, "0,0,NA,NA,%lf,%lf,%lf,%lf,%lf\n", rss0, mean0,
	    sqrt(rss0/(double)(n_ind-1)), 0.0, 0.0);

    for(i=0, k=1; i<n_chr; i++) {
      for(j=0; j<n_mar[i]; j++, k++) {
	index[0] = k*2-1; index[1] = k*2;
	sweep(xpx, tot_mar*2+2, index, 2, &err);

	if(err) {
	  printf("Error in sweep of marker %d-%d\n", i+1, j+1);
	  exit(1);
	}

	rss = xpx[tot_mar*2+1][tot_mar*2+1];
	mean = xpx[0][tot_mar*2+1];
	a = xpx[k*2-1][tot_mar*2+1]; d = xpx[k*2][tot_mar*2+1];
	sweep(xpx, tot_mar*2+2, index, 2, &err);
	fprintf(fp, "%d,%d,%s,%lf,%lf,%lf,%lf,%lf,%lf\n", i+1, 
		j+1,marker_names[i][j],
		(double)n_ind/2.0*log(rss0/rss)/log(10.0),
		rss, mean, sqrt(rss/(double)(n_ind-3)),a, d);

	printf(".");
      }
      printf("o");
    }
    printf("\n");

    free_hmm(n_ind, n_chr, p, q);
    free_xpx(tot_mar, xpx);

    fclose(fp);
  }


  /* all pairs */
  else if(!strcmp(lastarg, "pairs")) {

    if(!(fp=fopen(outfile, "w"))) {
      printf("Cannot write to %s\n", outfile);
      exit(1);
    }
    fprintf(fp, "chr1,mar1,name1,chr2,mar2,name2,LOD(1),LOD(2),");
    fprintf(fp, "LOD(1+2),LOD(1X2),LOD(1*2),");
    fprintf(fp, "mean,sigma,a1,d1,a2,d2,a1 x a2,a1 x d2,d1 x a2,d1 x d2\n");

    allocate_hmm(n_ind, n_chr, n_mar, &p, &q);
    allocate_xpx2(&xpx);

    printf(" -Running forward/backward equations\n");
    for(i=0; i<n_ind; i++)
      for(j=0; j<n_chr; j++)
	hmm(n_mar[j], theta[j], g[i][j], p[i][j], q[i][j], alpha, beta);

    printf(" -Analyzing all pairs of loci\n");
    for(i1=0, k1=0; i1<n_chr; i1++) {
      for(j1=0; j1<n_mar[i1]; j1++, k1++) {

	for(i2=0, k2=0; i2<n_chr; i2++) {
	  for(j2=0; j2<n_mar[i2]; j2++, k2++) {

	    if(k2 > k1) {
	      create_xpx2(n_chr, n_mar, n_ind, p, q, y, xpx, i1, j1, i2, j2);
	      sweep_xpx2(fp, n_ind, xpx, i1, j1, i2, j2, marker_names);
	    }

	  }
	}


	printf(".");
      }
      printf("o");
    }
    printf("\n");

    free_hmm(n_ind, n_chr, p, q);
    free_xpx2(xpx);

    fclose(fp);
  }

  /* forward selection with interactions */
  else if(!strcmp(lastarg, "inter")) {

    if(argc < 8) {
      printf("Give the number of terms to include by forward selection\n");
      printf("  and the value of delta to use in the BIC-delta criterion.\n");
      exit(1);
    }

    max_step = atoi(argv[6]);
    delta = atof(argv[7]);

    allocate_hmm(n_ind, n_chr, n_mar, &p, &q);

    /* allocate memory for (X y)'(X y) and X matrices and indices */
    allocate_inter(max_step, n_ind, n_chr, n_mar, &xpx, &x, &index_inter,
		   &index_c1, &index_m1, &index_c2, &index_m2, &index_work,
		   &flag);

    printf(" -Running forward/backward equations\n");
    for(i=0; i<n_ind; i++)
      for(j=0; j<n_chr; j++)
	hmm(n_mar[j], theta[j], g[i][j], p[i][j], q[i][j], alpha, beta);

    printf(" -Running forward selection: ");
    /* program to do forward selection */
    forward_inter(outfile, n_ind, n_chr, n_mar, max_step, p, q, y,
		  xpx, x, index_inter, index_c1, index_m1,
		  index_c2, index_m2, index_work, flag, delta, marker_names);
    printf("\n");

    free_hmm(n_ind, n_chr, p, q);

    /* free memory for X'X matrix and indices */
    free_inter(n_chr, xpx, x, index_inter, index_c1, index_m1, index_c2,
	       index_m2, index_work, flag);

  }

  /* forward selection */
  else {

    max_step = atoi(lastarg);

    allocate_hmm(n_ind, n_chr, n_mar, &p, &q);
    allocate_xpx(tot_mar, &xpx);

    printf(" -Running forward/backward equations\n");
    for(i=0; i<n_ind; i++)
      for(j=0; j<n_chr; j++)
	hmm(n_mar[j], theta[j], g[i][j], p[i][j], q[i][j], alpha, beta);

    printf(" -Creating (X y)'(X y) matrix\n");
    /* create (X y)' (X y) matrix */
    create_xpx(n_chr, n_mar, tot_mar, n_ind, p, q, y, xpx);

    printf(" -Running forward selection\n");
    forward(outfile, n_chr, n_mar, n_ind, tot_mar, max_step, xpx, marker_names);

    free_hmm(n_ind, n_chr, p, q);
    free_xpx(tot_mar, xpx);
  }

  free_map(n_chr, n_mar, theta, alpha, beta, marker_names);
  free_data(n_ind, n_chr, n_mar, y, g);
}


/* end of f2_main.c */
