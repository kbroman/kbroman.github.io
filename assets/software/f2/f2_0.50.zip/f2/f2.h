/**********************************************************************
 *
 * f2.h
 *
 * copyright (C) 2000 Karl W. Broman, Johns Hopkins University
 * Licensed under the GNU General Public License version 2 (June, 1991)
 *
 * January, 2000; August, 1998 
 *
 *    This is the program "F2," whose aim is to provide a method for 
 * using forward selection to identify multiple QTLs segregating in an 
 * F2-intercross.
 *
 *    The program should be run with five command-line arguments:
 * the map file, genotype data file, phenotype data file, output file
 * and a final argument as follows:
 *
 *     est     re-estimate the recombination fractions using Lander/Green
 *     dat     estimate Pr(AA|x) and Pr(BB|x) write out the (X y) matrix
 *     anova   do ANOVA (one step of f.s.) and output results for each marker
 *     pairs   do all pairs of markers including the interaction
 *     #       do forward selection up to # markers (# is any positive integer)
 *     inter   do forward selection allowing pairwise interactions:
 *                [Here also give two addt'l command-line arguments:
 *                   the maximum number of terms to include
 *                   the delta to use in BIC-delta]
 *
 * For example:
 *
 *    f2 map.txt gen.txt pheno.txt out.csv est
 *    f2 map.txt gen.txt pheno.txt out.csv dat
 *    f2 map.txt gen.txt pheno.txt out.csv anova
 *    f2 map.txt gen.txt pheno.txt out.csv pairs
 *    f2 map.txt gen.txt pheno.txt out.csv 20
 *    f2 map.txt gen.txt pheno.txt out.csv inter 5 2.5
 *
 **********************************************************************
 *
 * The map file should be in the following form (thetas = rec. fracs.)
 *
 *   n_chr
 *   n_mar1 theta1 theta2 ... theta(n_mar1-1)
 *   marker_name1
 *   marker_name2
 *   ...
 *   n_mar2 theta1 theta2 ... theta(n_mar2-1)
 *   ...
 *
 **********************************************************************
 *
 * The genotype data file should be in the following form
 *
 *   n_ind
 *   gen11 gen12 gen13 ...
 *   gen21 gen22 gen23 ...
 *   ...
 *
 * The genotypes should be either 0 (missing) 1 (AA) 2 (AB) 3 (BB)
 *   4 (not BB) or 5 (not AA)
 *
 **********************************************************************
 *
 * The phenotype data file should be in the following form
 *
 *   n_ind
 *   phen1
 *   phen2
 *   ...
 *
 **********************************************************************
 *
 * The output file will be comma-delimited (suitable for import into
 * Excel as a "CSV file")
 *
 **********************************************************************
 *
 * Files in the F2 program:
 *
 *     f2_main.c      main function
 *     f2_io.c        i/o functions: load map and data files
 *     f2_lg.c        Lander-Green/HMM stuff
 *     f2_anal.c      creation of XPX matrix, forward selection,
 *                        ANOVA, all pairs
 *     f2_util.c      memory allocation
 *     sweep.c        sweep algorithm (to do the regressions)
 *
 **********************************************************************
 *
 * n_chr       = number of chromosomes
 * n_mar[j]    = number of markers on chr j; j=0...n_chr-1
 * max_n_mar   = maximum number of markers on a chromosome
 * theta[j][k] = recombination fraction between markers k and k+1
 *               for k = 0...(n_mar[j]-2)
 * n_ind       = number of individuals
 * y[i]        = phenotype of individual i
 * g[i][j][k]  = genotype for individual i at marker k on chr j
 *               0 (missing) 1 (AA) 2 (AB) 3(BB) 4 (not BB) 5 (not AA)
 * p[i][j][k]  = Pr(AA at k|x) (to be calculated) (k=0...n_mar-1)
 * q[i][j][k]  = Pr(BB at k|x) (to be calculated) (k=0...n_mar-1)
 * alpha[i][k] = used in intermediate calcs (k=0...max_n_mar-1; i=0...3)
 * beta[i][k]  = used in intermediate calcs (k=0...max_n_mar-1; i=0...3)
 * newtheta    = updated version of theta when re-estimating recomb. fracs
 * exprec      = expected number of recombs (used when re-est rf's)
 *
 **********************************************************************
 *
 * f2_main:
 *
 *     void main()  give mapfile datfile & outfile as command-line arguments
 *
 * f2_io: 
 *
 *    This part of the program does the input of the map, marker and
 * genetic data, and allocates and frees memory for those things.
 *
 *     load_map
 *     free_map
 *     load_data
 *     free_data
 *
 * f2_anal:
 *
 *    This part of the program does the forward selection and also
 * creates the (X y)' (X y) matrix.  It also has routines for creating
 * the (X y)'(X y) matrix when analyzing all pairs of markers, and
 * for performing that all pairs analysis.
 *
 *     create_xpx
 *     forward
 *     create_xpx2
 *     sweep_xpx2
 *
 * f2_lg.c: 
 *
 *    This part of the program uses a Lander-Green-type algorithm,
 * the forward/backward algorithms for HMMs, to calculate, for a
 * single individual, Pr(AA|x) and Pr(BB|x) where x is the set of
 * genetic data on a chromosome.
 *
 *    hmm
 *    emit
 *    step
 *    lg
 *    nrec
 *
 * f2_util.c:
 *
 *    This part of the program does basically allocation of memory.
 *
 *     allocate_lg
 *     free_lg
 *     allocate_hmm
 *     free_hmm
 *     allocate_xpx
 *     free_xpx
 *     allocate_xpx2
 *     free_xpx2
 *     allocate_inter
 *     free_inter
 *
 **********************************************************************/

/**********************************************************************
 * load_map / f2_io.c
 *
 * loads map information
 *
 * map file should be in the following form: (thetas = recomb. fracs
 *
 * n_chr
 * n_mar1 theta1 theta2 ... theta(n_mar1-1)
 * marker_name1
 * marker_name2
 * ...
 * n_mar2 theta1 theta2 ... theta(n_mar2-1)
 * ...
 **********************************************************************/
void load_map(char *file, int *n_chr, int **n_mar, int *max_n_mar,
	      double ***theta, double ***alpha, double ***beta, 
	      char ****marker_names);

/**********************************************************************
 * free_map / f2_io.c
 *
 * free memory for map
 **********************************************************************/
void free_map(int n_chr, int *n_mar, double **theta,
	      double **alpha, double **beta, char ***marker_names);

/**********************************************************************
 * load_data / f2_io.c
 *
 * loads phenotype and genotype data
 *
 * genotype data file should be in the following form:
 *
 * n_ind
 * gen11 gen12 gen13 ...
 * gen21 gen22 gen23 ...
 * ...
 *
 * phenotype data file should be in the following form:
 *
 * n_ind
 * phen1
 * phen2
 * ...
 **********************************************************************/
void load_data(char *genfile, char *phefile, int n_chr, int *n_mar,
	       int *n_ind, double **y, int ****g);

/**********************************************************************
 * free_data / f2_io.h
 * 
 * free memory for phenotypes and genotypes
 **********************************************************************/
void free_data(int n_ind, int n_chr, int *n_mar, double *y, int ***g);

/**********************************************************************
 * create_xpx / f2_anal.c
 *
 * Forms the (X y)'(X y) matrix for use in ANOVA and forward selection
 **********************************************************************/
void create_xpx(int n_chr, int *n_mar, int tot_mar, int n_ind,
		double ***p, double ***q, double *y, double **xpx);

/**********************************************************************
 * forward / f2_anal.c
 *
 * Perform forward selection
 **********************************************************************/
void forward(char *file, int n_chr, int *n_mar, int n_ind,
	     int tot_mar, int max_step, double **xpx, char ***marker_names);

/**********************************************************************
 * create_xpx2 / f2_anal.c
 *
 * Creates the (X y)'(X y) matrix for a pair of markers, including the
 * interactions.
 **********************************************************************/
void create_xpx2(int n_chr, int *n_mar, int n_ind,
		 double ***p, double ***q, double *y, double **xpx,
		 int j1, int k1, int j2, int k2);

/**********************************************************************
 * sweep_xpx2 / f2_anal.c
 *
 * For a pair of markers, does the regression of each marker on its own,
 * of the two markers together (additively), and of the two markers with
 * interaction terms included.
 **********************************************************************/
void sweep_xpx2(FILE *fp, int n_ind, double **xpx, int i1, int j1,
		int i2, int j2, char ***marker_names);


/**********************************************************************
 * forward_inter / f2_anal.c
 *
 * Perform forward selection, including possible interactions
 **********************************************************************/
void forward_inter(char *outfile, int n_ind, int n_chr, int *n_mar,
		   int max_step, double ***p, double ***q, double *y,
		   double **xpx, double **x, int *index_inter, int *index_c1,
		   int *index_m1, int *index_c2, int *index_m2,
		   int *index_work, int **flag, double delta,
		   char ***marker_names);

/**********************************************************************
 * create_xpx3 / f2_anal.c
 *
 * Creates the (X y)'(X y) matrix for a pair of markers, including the
 * interactions.
 **********************************************************************/
void create_xpx3(int n_chr, int *n_mar, int n_ind, int cur_step,
		 double ***p, double ***q, double *y, double **xpx,
		 double **x, int *index_inter, int *index_c1,
		 int *index_m1, int *index_c2, int *index_m2,
		 int **flag, int *n_col);


/**********************************************************************
 * hmm / f2_lg.c
 * 
 * this program uses the Lander-green algorithm to calculate
 * Pr(AA at k|x) and Pr(BB at k|x) at each locus k
 **********************************************************************/
void hmm(int n_mar, double *theta, int *g, double *p, double *q,
	 double **alpha, double **beta);

/**********************************************************************
 * emit / f2_lg.c
 *
 * calculates Pr(observe genotype g | true genotype is i)
 **********************************************************************/
double emit(int g, int i);

/**********************************************************************
 * step / f2_lg.c
 * calculates Pr(gen at k+1 is j | gen at k is i)
 **********************************************************************/
double step(int i, int j, double theta);

/**********************************************************************
 * lg / f2_lg.c
 *
 * this program uses the Lander-green algorithm to re-estimate
 * the recombination fractions
 **********************************************************************/
void lg(int n_mar, double *theta, int *g, double *exprec,
	double **alpha, double **beta);

/**********************************************************************
 * nrec / f2_lg.c
 *
 * calculates number of recombinations between states i and j
 * where i,j = 0 (AA), 1 (AB), 2 (BA), or 3 (BB)
 **********************************************************************/
double nrec(int i, int j) ;

/**********************************************************************
 * allocate_lg / f2_util.c
 *
 *     This function allocates memory for use in the function performing
 * Lander-Green to re-estimate the rec fracs between markers.
 **********************************************************************/
void allocate_lg(int n_chr, int *n_mar, int max_n_mar,
		 double ***newtheta, double **exprec);

/**********************************************************************
 * free_lg / f2_util.c
 * frees the lander-green stuff
 **********************************************************************/
void free_lg(int n_chr, double **newtheta, double *exprec);

/**********************************************************************
 * allocate_hmm / f2_util.c
 *
 * Allocates memory for use in the function which uses the forward/
 * backward equations to calculate Pr(AA|x) and Pr(BB|x) for each locus
 **********************************************************************/
void allocate_hmm(int n_ind, int n_chr, int *n_mar,
		  double ****p, double ****q);

/**********************************************************************
 * free_hmm / f2_util.c
 * 
 * frees the hmm memory
 **********************************************************************/
void free_hmm(int n_ind, int n_chr, double ***p, double ***q);

/**********************************************************************
 * allocate_xpx / f2_util.c
 *
 * Allocates memory for the (X y)'(X y) matrix for ANOVA and
 * forward selection.
 **********************************************************************/
void allocate_xpx(int tot_mar, double ***xpx);

/**********************************************************************
 * free_xpx / f2_util.c
 *
 * frees the memory for the (X y)'(X y) matrix
 **********************************************************************/
void free_xpx(int tot_mar, double **xpx);

/**********************************************************************
 * allocate_xpx2 / f2_util.c
 *
 * Allocates memory for the (X y)'(X y) matrix for the analysis of all
 * pairs of loci (including interactions)
 **********************************************************************/
void allocate_xpx2(double ***xpx);

/**********************************************************************
 * free_xpx2 / f2_util.c
 * 
 * frees the memory for the (X y)'(X y) matrix
 **********************************************************************/
void free_xpx2(double **xpx);

/**********************************************************************
 * allocate_inter / f2_util.c
 *
 * Allocates memory for the (X y)'(X y) matrix for doing forward
 * selection, possibly including pairwise interactions
 **********************************************************************/
void allocate_inter(int max_step, int n_ind, int n_chr, int *n_mar,
		    double ***xpx, double ***x,
		    int **index_inter, int **index_c1, int **index_m1,
		    int **index_c2, int **index_m2, int **index_work,
		    int ***flag);

/**********************************************************************
 * free_inter / f2_util.c
 * 
 * frees the memory for the (X y)'(X y) matrix and indices
 **********************************************************************/
void free_inter(int n_chr, double **xpx, double **x, int *index_inter,
		int *index_c1, int *index_m1, int *index_c2, int *index_m2,
		int *index_work, int **flag);

