/**********************************************************************
 *
 * f2_util.c
 *
 * copyright (C) 2000 Karl W. Broman, Johns Hopkins University
 * Licensed under the GNU General Public License version 2 (June, 1991)
 *
 * January, 2000; August, 1998 
 *
 *    This is part of the program "F2," whose aim is to provide a
 * method for using forward selection to identify multiple QTLs
 * segregating in an F2-intercross.
 *
 *    This part of the program does basically allocation of memory.
 *
 **********************************************************************
 *
 * Functions:
 *
 *     allocate_lg
 *     free_lg
 *     allocate_hmm
 *     free_hmm
 *     allocate_xpx
 *     free_xpx
 *     allocate_xpx2
 *     free_xpx2
 *     allocate_inter
 *     free_inter
 *
 **********************************************************************/

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "f2.h"

/**********************************************************************
 * allocate_lg
 *
 *     This function allocates memory for use in the function performing
 * Lander-Green to re-estimate the rec fracs between markers.
 **********************************************************************/
void allocate_lg(int n_chr, int *n_mar, int max_n_mar,
		 double ***newtheta, double **exprec)
{
  int i;

  *newtheta = (double **)malloc(sizeof(double *)*n_chr);
  *exprec = (double *)malloc(sizeof(double)*(max_n_mar-1));
  if(!(*newtheta) || !(*exprec)) {
    printf("Cannot allocate enough memory in allocate_lg (1)\n");
    exit(1);
  }

  for(i=0; i<n_chr; i++) {
    (*newtheta)[i] = (double *)malloc(sizeof(double)*(n_mar[i]-1));
    if(!((*newtheta)[i])) {
      printf("Cannot allocate enough memory in allocate_lg (2-%d)\n", i);
      exit(1);
    }
  }
}

/**********************************************************************
 * free_lg: frees the lander-green stuff
 **********************************************************************/
void free_lg(int n_chr, double **newtheta, double *exprec)
{
  int i;

  free(exprec);
  for(i=0; i<n_chr; i++) free(newtheta[i]);
  free(newtheta);
}


/**********************************************************************
 * allocate_hmm
 *
 * Allocates memory for use in the function which uses the forward/
 * backward equations to calculate Pr(AA|x) and Pr(BB|x) for each locus
 **********************************************************************/
void allocate_hmm(int n_ind, int n_chr, int *n_mar,
		  double ****p, double ****q)
{
  int i, j;

  *p = (double ***)malloc(sizeof(double **)*n_ind);
  *q = (double ***)malloc(sizeof(double **)*n_ind);
  if(!(*p) || !(*q)) {
    printf("Cannot allocate enough memory in allocate_hmm (1)\n");
    exit(1);
  }

  for(i=0; i<n_ind; i++) {
    (*p)[i] = (double **)malloc(sizeof(double *)*n_chr);
    (*q)[i] = (double **)malloc(sizeof(double *)*n_chr);
    if(!((*p)[i]) || !((*q)[i])) {
      printf("Cannot allocate enough memory in allocate_hmm (2-%d)\n", i);
      exit(1);
    }

    for(j=0; j<n_chr; j++) {
      (*p)[i][j] = (double *)malloc(sizeof(double)*n_mar[j]);
      (*q)[i][j] = (double *)malloc(sizeof(double)*n_mar[j]);
      if(!((*p)[i][j]) || !((*q)[i][j])) {
	printf("Cannot allocate enough memory in allocate_hmm (3-%d,%d)\n",
	       i, j);
	exit(1);
      }
    }
  }
}

/**********************************************************************
 * free_hmm: frees the hmm memory
 **********************************************************************/
void free_hmm(int n_ind, int n_chr, double ***p, double ***q)
{
  int i, j;

  for(i=0; i<n_ind; i++) {
    for(j=0; j<n_chr; j++) {
      free(p[i][j]);
      free(q[i][j]);
    }
    free(p[i]);
    free(q[i]);
  }
  free(p);
  free(q);
}


/**********************************************************************
 * allocate_xpx
 *
 * Allocates memory for the (X y)'(X y) matrix for ANOVA and
 * forward selection.
 **********************************************************************/
void allocate_xpx(int tot_mar, double ***xpx)
{
  int i;
  double *a;

  *xpx = (double **)malloc(sizeof(double *)*(tot_mar*2+2));
  if(!(*xpx)) {
    printf("Cannot allocate enough memory in allocate_xpx (1)\n");
    exit(1);
  }
  a = (double *)malloc(sizeof(double)*(tot_mar*2+2)*(tot_mar*2+2));
  if(!a) {
    printf("Cannot allocate enough memory in allocate_xpx (2)\n");
    exit(1);
  }

  for(i=0; i<tot_mar*2+2; i++)
    (*xpx)[i] = a+i*(tot_mar*2+2);

}

/**********************************************************************
 * free_xpx: frees the memory for the (X y)'(X y) matrix
 **********************************************************************/
void free_xpx(int tot_mar, double **xpx)
{
  free(xpx[0]);
  free(xpx);
}



/**********************************************************************
 * allocate_xpx2
 *
 * Allocates memory for the (X y)'(X y) matrix for the analysis of all
 * pairs of loci (including interactions)
 **********************************************************************/
void allocate_xpx2(double ***xpx)
{
  int i, n=10;
  double *a;

  *xpx = (double **)malloc(sizeof(double *)*n);
  if(!(*xpx)) {
    printf("Cannot allocate enough memory in allocate_xpx2 (1)\n");
    exit(1);
  }

  a = (double *)malloc(sizeof(double)*n*n);
  if(!a) {
    printf("Cannot allocate enough memory in allocate_xpx2 (2)\n");
    exit(1);
  }

  for(i=0; i<n; i++)
    (*xpx)[i] = a + i*n;

}

/**********************************************************************
 * free_xpx2: frees the memory for the (X y)'(X y) matrix
 **********************************************************************/
void free_xpx2(double **xpx)
{
  free(xpx[0]);
  free(xpx);
}



/**********************************************************************
 * allocate_inter
 *
 * Allocates memory for the (X y)'(X y) matrix for doing forward
 * selection, possibly including pairwise interactions
 **********************************************************************/
void allocate_inter(int max_step, int n_ind, int n_chr, int *n_mar,
		    double ***xpx, double ***x,
		    int **index_inter, int **index_c1, int **index_m1,
		    int **index_c2, int **index_m2, int **index_work,
		    int ***flag)
{
  int i, n;
  double *a;

  n = max_step*8+2;
  *xpx = (double **)malloc(sizeof(double *)*n);
  if(!(*xpx)) {
    printf("Cannot allocate enough memory in allocate_inter (1)\n");
    exit(1);
  }
  a = (double *)malloc(sizeof(double)*n*n);
  if(!a) {
    printf("Cannot allocate enough memory in allocate_inter (2)\n");
    exit(1);
  }
  for(i=0; i<n; i++)
    (*xpx)[i] = a + i*n;

  n = max_step*8;
  *x = (double **)malloc(sizeof(double *)*n_ind);
  if(!(*x)) {
    printf("Cannot allocate enough memory in allocate_inter (2.25)\n");
    exit(1);
  }
  a = (double *)malloc(sizeof(double)*n*n_ind);
  if(!a) {
    printf("Cannot allocate enough memory in allocate_inter (2.5)\n");
    exit(1);
  }
  for(i=0; i<n_ind; i++)
    (*x)[i] = a + i*n;

  *flag = (int **)malloc(sizeof(int *)*n_chr);
  if(!(*flag)) {
    printf("Cannot allocate enough memory in allocate_inter (2.75)\n");
    exit(1);
  }
  for(i=0; i<n_chr; i++) {
    (*flag)[i] = (int *)malloc(sizeof(int)*n_mar[i]);
    if(!((*flag)[i])) {
      printf("Cannot allocate enough memory in allocate_inter (2.75-%d)\n", i);
      exit(1);
    }
  }

  *index_inter = (int *)malloc(sizeof(int)*max_step);
  *index_c1 = (int *)malloc(sizeof(int)*max_step);
  *index_m1 = (int *)malloc(sizeof(int)*max_step);
  *index_c2 = (int *)malloc(sizeof(int)*max_step);
  *index_m2 = (int *)malloc(sizeof(int)*max_step);
  *index_work = (int *)malloc(sizeof(int)*(n+1));
  if(!(*index_inter) || !(*index_c1) || !(*index_m1) ||
     !(*index_c2) || !(*index_m2) || !(*index_work)) {
    printf("Cannot allocate enough memory in allocate_inter (3)\n");
    exit(1);
  }

}

/**********************************************************************
 * free_inter: frees the memory for the (X y)'(X y) matrix and indices
 **********************************************************************/
void free_inter(int n_chr, double **xpx, double **x, int *index_inter,
		int *index_c1, int *index_m1, int *index_c2, int *index_m2,
		int *index_work, int **flag)
{
  int i;

  free(xpx[0]);
  free(xpx);

  free(x[0]);
  free(x);

  free(index_inter);
  free(index_c1);
  free(index_m1);
  free(index_c2);
  free(index_m2);
  free(index_work);

  for(i=0; i<n_chr; i++) free(flag[i]);
  free(flag);
}

/* end of f2_util.c */

