/**********************************************************************
 *
 * f2_anal.c
 *
 * copyright (C) 2000 Karl W. Broman, Johns Hopkins University
 * Licensed under the GNU General Public License version 2 (June, 1991)
 *
 * January, 2000; August, 1998 
 *
 *    This is part of the program "F2," whose aim is to provide a
 * method for using forward selection to identify multiple QTLs
 * segregating in an F2-intercross.
 *
 *    This part of the program does the forward selection and also
 * creates the (X y)' (X y) matrix.  It also has routines for creating
 * the (X y)'(X y) matrix when analyzing all pairs of markers, and
 * for performing that all pairs analysis.
 *
 **********************************************************************
 *
 * Functions:
 *
 *     create_xpx
 *     forward
 *     create_xpx2
 *     sweep_xpx2
 *     forward_inter
 *     create_xpx3
 *
 **********************************************************************/

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "f2.h"
#include "sweep.h"

/**********************************************************************
 * create_xpx
 *
 * Forms the (X y)'(X y) matrix for use in ANOVA and forward selection
 **********************************************************************/
void create_xpx(int n_chr, int *n_mar, int tot_mar, int n_ind,
		double ***p, double ***q, double *y, double **xpx)
{
  int i, j1, j2, k1, k2, s1, s2;

  for(s1=0; s1<tot_mar*2+2; s1++)
    for(s2=0; s2<tot_mar*2+2; s2++)
      xpx[s1][s2] = 0.0;

  xpx[0][0] = (double)n_ind;

  for(i=0; i<n_ind; i++) {

    xpx[0][tot_mar*2+1] = (xpx[tot_mar*2+1][0] += y[i]);
    xpx[tot_mar*2+1][tot_mar*2+1] += y[i]*y[i];

    for(j1=0,s1=1; j1<n_chr; j1++) {
      for(k1=0; k1<n_mar[j1]; k1++, s1++) {

	xpx[0][2*s1-1] = (xpx[2*s1-1][0] += (p[i][j1][k1]-q[i][j1][k1]));
	xpx[0][2*s1] = (xpx[2*s1][0] += (1.0-p[i][j1][k1]-q[i][j1][k1]));

	xpx[2*tot_mar+1][2*s1-1] =
	  (xpx[2*s1-1][2*tot_mar+1] += (p[i][j1][k1]-q[i][j1][k1])*y[i]);
	xpx[2*tot_mar+1][2*s1] =
	  (xpx[2*s1][2*tot_mar+1] += (1.0-p[i][j1][k1]-q[i][j1][k1])*y[i]);


	for(j2=0,s2=1; j2<n_chr; j2++) {
	  for(k2=0; k2<n_mar[j2]; k2++, s2++) {
	    xpx[2*s2-1][2*s1-1] +=
	      (p[i][j1][k1]-q[i][j1][k1])*(p[i][j2][k2]-q[i][j2][k2]);
	    xpx[2*s2][2*s1] +=
	      (1.0-p[i][j1][k1]-q[i][j1][k1])*(1.0-p[i][j2][k2]-q[i][j2][k2]);
	    xpx[2*s2][2*s1-1] +=
	      (p[i][j1][k1]-q[i][j1][k1])*(1.0-p[i][j2][k2]-q[i][j2][k2]);
	    xpx[2*s2-1][2*s1] +=
	      (1.0-p[i][j1][k1]-q[i][j1][k1])*(p[i][j2][k2]-q[i][j2][k2]);
	  }
	}
      }
    }
  }
}


/**********************************************************************
 * forward
 *
 * Perform forward selection
 **********************************************************************/
void forward(char *file, int n_chr, int *n_mar, int n_ind,
	     int tot_mar, int max_step, double **xpx, char ***marker_names)
{
  int i, j, k, s;
  int size, sizem1, **flag;
  double rss0, prevrss, *rss;
  int index[2], *index_chr, *index_mar, *index_spot;
  double bic_val[8], minrss, minbic, bic;
  int n_bic = 8, err;
  FILE *fp;

  if(!(fp=fopen(file, "w"))) {
    printf("Cannot write to %s\n", file);
    exit(1);
  }

  /* allocate space */
  flag = (int **)malloc(sizeof(int *)*n_chr);
  rss = (double *)malloc(sizeof(double)*max_step);
  index_chr = (int *)malloc(sizeof(int)*max_step);
  index_mar = (int *)malloc(sizeof(int)*max_step);
  index_spot = (int *)malloc(sizeof(int)*max_step);
  if(!flag || !index_chr || !index_mar || !index_spot || !rss) {
    printf("Cannot allocate sufficient memory in forward\n");
    exit(1);
  }
  for(i=0; i<n_chr; i++) {
    flag[i] = (int *)malloc(sizeof(int)*n_mar[i]);
    if(!(flag[i])) {
      printf("Cannot allocate sufficient memory in forward\n");
      exit(1);
    }
  }

  for(i=0; i<n_bic; i++)
    bic_val[i] = 1.0 + 0.5*(double)i;

  size = tot_mar*2+2;
  sizem1 = size-1;

  /* set flags to 0 */
  for(i=0; i<n_chr; i++)
    for( j=0; j<n_mar[i]; j++)
      flag[i][j] = 0;

  /* sweep intercept */
  index[0] = 0;
  sweep(xpx, size, index, 1, &err);
  if(err) { printf("Error in sweep\n"); exit(1); }
  prevrss = rss0 = xpx[sizem1][sizem1];
  fprintf(fp, "chr,mar,name,RSS,LOD,");
  fprintf(fp, "mean,sigma,a,d\n");
  fprintf(fp, ",,,%lf,,", rss0);
  fprintf(fp, "%lf,%lf\n", xpx[0][sizem1],sqrt(rss0/((double)n_ind-1.0)));

  for(i=0; i<max_step; i++) {
    minrss = rss0;
    for(j=0, s=1; j<n_chr; j++) {
      for(k=0; k<n_mar[j]; k++, s++) {
	if(!flag[j][k]) { /* not already chosen */
	  index[0] = 2*s-1; index[1] = 2*s;
	  sweep(xpx, size, index, 2, &err);
	  if(err) { printf("Error in sweep\n"); exit(1); }
	  if(xpx[sizem1][sizem1] < minrss) {
	    minrss = xpx[sizem1][sizem1];
	    index_chr[i] = j;
	    index_mar[i] = k;
	    index_spot[i] = s;
	  }
	  sweep(xpx, size, index, 2, &err);
	  if(err) { printf("Error in sweep\n"); exit(1); }
	}
      }
    }
    index[0] = index_spot[i]*2-1; index[1] = index_spot[i]*2;
    sweep(xpx, size, index, 2, &err);
    if(err) { printf("Error in sweep\n"); exit(1); }

    fprintf(fp, "%d,%d,%s,%lf,%lf,", index_chr[i]+1, index_mar[i]+1,
	    marker_names[index_chr[i]][index_mar[i]],
	    minrss, (double)(n_ind)/2.0*log(prevrss/minrss)/log(10.0));
    fprintf(fp, "%lf,%lf", xpx[0][sizem1],sqrt(minrss/((double)n_ind-2*i-3)));
    for(j=0; j < (i+1); j++)
      fprintf(fp, ",%lf,%lf", xpx[index_spot[j]*2-1][sizem1],
	      xpx[index_spot[j]*2][sizem1]);
    fprintf(fp, "\n");

    printf("%2d ", i+1);
    flag[index_chr[i]][index_mar[i]] = 1;
    prevrss = rss[i] = minrss;
  }
  printf("\n");

  fprintf(fp, "\n\n");
  for(i=0; i<n_bic; i++) {
    minbic = log(rss0) + bic_val[i]*log((double)n_ind)/(double)n_ind;
    k = -1;
    for(j=0; j<max_step; j++) {
      bic = log(rss[j])+bic_val[i]*log((double)n_ind)/(double)n_ind*
	(double)(2*j+3);
      if(bic < minbic) {
	minbic = bic; k = j;
      }
    }
    fprintf(fp, "BIC-%.1lf,%d", bic_val[i], k+1);
    for(j=0; j<k+1; j++)
      fprintf(fp, ",%d %d", index_chr[j]+1, index_mar[j]+1);
    fprintf(fp, "\n");
  }

  /* free space */
  for(i=0; i<n_chr; i++) free(flag[i]);
  free(flag);
  free(index_chr);
  free(index_mar);
  free(index_spot);
  fclose(fp);

}


/**********************************************************************
 * create_xpx2
 *
 * Creates the (X y)'(X y) matrix for a pair of markers, including the
 * interactions.
 **********************************************************************/
void create_xpx2(int n_chr, int *n_mar, int n_ind,
		 double ***p, double ***q, double *y, double **xpx,
		 int j1, int k1, int j2, int k2)
{
  int i, s1, s2;
  double a=0, b=0;

  for(s1=0; s1<10; s1++)
    for(s2=0; s2<10; s2++)
      xpx[s1][s2] = 0.0;

  xpx[0][0] = (double)n_ind;

  for(i=0; i<n_ind; i++) {

    xpx[0][1] = (xpx[1][0] += (p[i][j1][k1] - q[i][j1][k1]));
    xpx[0][2] = (xpx[2][0] += (1.0 - p[i][j1][k1] - q[i][j1][k1]));
    xpx[0][3] = (xpx[3][0] += (p[i][j2][k2] - q[i][j2][k2]));
    xpx[0][4] = (xpx[4][0] += (1.0 - p[i][j2][k2] - q[i][j2][k2]));

    xpx[0][5] = (xpx[5][0] += (p[i][j1][k1] - q[i][j1][k1]) *
		 (p[i][j2][k2] - q[i][j2][k2]));
    xpx[0][6] = (xpx[6][0] += (p[i][j1][k1] - q[i][j1][k1]) *
		 (1.0 - p[i][j2][k2] - q[i][j2][k2]));
    xpx[0][7] = (xpx[7][0] += (1.0 - p[i][j1][k1] - q[i][j1][k1]) *
		 (p[i][j2][k2] - q[i][j2][k2]));
    xpx[0][8] = (xpx[8][0] += (1.0 - p[i][j1][k1] - q[i][j1][k1]) *
		 (1.0 - p[i][j2][k2] - q[i][j2][k2]));

    xpx[0][9] = (xpx[9][0] += y[i]);

    for(s1=1; s1<10; s1++) {
      switch(s1) {
      case 1: a = p[i][j1][k1] - q[i][j1][k1]; break;
      case 2: a = 1.0 - p[i][j1][k1] - q[i][j1][k1]; break;
      case 3: a = p[i][j2][k2] - q[i][j2][k2]; break;
      case 4: a = 1.0 - p[i][j2][k2] - q[i][j2][k2]; break;
      case 5:
	a = (p[i][j1][k1]-q[i][j1][k1]) * (p[i][j2][k2]-q[i][j2][k2]);
	break;
      case 6:
	a = (p[i][j1][k1]-q[i][j1][k1]) * (1.0-p[i][j2][k2]-q[i][j2][k2]);
	break;
      case 7:
	a = (1.0-p[i][j1][k1]-q[i][j1][k1]) * (p[i][j2][k2]-q[i][j2][k2]);
	break;
      case 8:
	a = (1.0-p[i][j1][k1]-q[i][j1][k1])*(1.0-p[i][j2][k2]-q[i][j2][k2]);
	break;
      case 9:
	a = y[i];
	break;
      }
      xpx[s1][s1] += a*a;

      for(s2=s1+1; s2<10; s2++) {
	switch(s2) {
	case 1: b = p[i][j1][k1] - q[i][j1][k1]; break;
	case 2: b = 1.0 - p[i][j1][k1] - q[i][j1][k1]; break;
	case 3: b = p[i][j2][k2] - q[i][j2][k2]; break;
	case 4: b = 1.0 - p[i][j2][k2] - q[i][j2][k2]; break;
	case 5:
	  b = (p[i][j1][k1]-q[i][j1][k1]) * (p[i][j2][k2]-q[i][j2][k2]);
	  break;
	case 6:
	  b = (p[i][j1][k1]-q[i][j1][k1]) * (1.0-p[i][j2][k2]-q[i][j2][k2]);
	  break;
	case 7:
	  b = (1.0-p[i][j1][k1]-q[i][j1][k1]) * (p[i][j2][k2]-q[i][j2][k2]);
	  break;
	case 8:
	  b=(1.0-p[i][j1][k1]-q[i][j1][k1])*(1.0-p[i][j2][k2]-q[i][j2][k2]);
	  break;
	case 9:
	  b = y[i];
	  break;
	}
	xpx[s1][s2] = (xpx[s2][s1] += a*b);
      }
    }
  }
}


/**********************************************************************
 * sweep_xpx2
 *
 * For a pair of markers, does the regression of each marker on its own,
 * of the two markers together (additively), and of the two markers with
 * interaction terms included.
 **********************************************************************/
void sweep_xpx2(FILE *fp, int n_ind, double **xpx, int i1, int j1,
		int i2, int j2, char ***marker_names)
{
  int index[5], i, err;
  double rss, rss0, rss1, rss2, rss3;

  /* sweep intercept */
  index[0] = 0;
  sweep(xpx, 10, index, 1, &err);
  if(err) { printf("*"); return; }
  rss0 = xpx[9][9];

  /* sweep first marker */
  for(i=0; i<2; i++) index[i] = i+1;
  sweep(xpx, 10, index, 2, &err);
  if(err) { printf("*"); return; }
  rss1 = xpx[9][9];
  sweep(xpx, 10, index, 2, &err);
  if(err) { printf("*"); return; }

  /* sweep second marker */
  for(i=0; i<2; i++) index[i] = i+3;
  sweep(xpx, 10, index, 2, &err);
  if(err) { printf("*"); return; }
  rss2 = xpx[9][9];

  /* both markers swept */
  for(i=0; i<2; i++) index[i] = i+1;
  sweep(xpx, 10, index, 2, &err);
  if(err) { printf("*"); return; }
  rss3 = xpx[9][9];


  /* sweep interaction */
  for(i=0; i<4; i++) index[i] = i+5;
  sweep(xpx, 10, index, 4, &err);
  if(err) { printf("*"); return; }
  rss = xpx[9][9];

  /* print if LOD for both markers + interactions is > 3.0 */
  if((double)n_ind/2.0*log(rss0/rss)/log(10.0) > 3.0) {
    fprintf(fp, "%d,%d,%s,%d,%d,%s,", i1+1, j1+1, 
	    marker_names[i1][j1], i2+1, j2+1, marker_names[i2][j2]);
    fprintf(fp, "%lf,%lf,%lf,%lf,%lf,",
	    (double)n_ind/2.0*log(rss0/rss1)/log(10.0),
	    (double)n_ind/2.0*log(rss0/rss2)/log(10.0),
	    (double)n_ind/2.0*log(rss0/rss3)/log(10.0),
	    (double)n_ind/2.0*log(rss3/rss)/log(10.0),
	    (double)n_ind/2.0*log(rss0/rss)/log(10.0));
    fprintf(fp, "%lf,%lf", xpx[0][9], sqrt(xpx[9][9]/(double)(n_ind-9)));
    for(i=1; i<9; i++)
      fprintf(fp, ",%lf", xpx[i][9]);
    fprintf(fp, "\n");
  }

}


/**********************************************************************
 * forward_inter
 *
 * Perform forward selection, including possible interactions
 **********************************************************************/
void forward_inter(char *outfile, int n_ind, int n_chr, int *n_mar,
		   int max_step, double ***p, double ***q, double *y,
		   double **xpx, double **x, int *index_inter, int *index_c1,
		   int *index_m1, int *index_c2, int *index_m2,
		   int *index_work, int **flag, double delta,
		   char ***marker_names)
{
  FILE *fp;
  int i, j, c1, m1, c2, m2;
  double a, b, rss0, rss_min, bic_min, rss_cur, bic_cur;
  int keep_c1=0, keep_m1=0, keep_c2=0, keep_m2=0, keep_inter=0, keep_nterm=0;
  int n_col, used, err;

  if(!(fp=fopen(outfile, "w"))) {
    printf("Cannot write to %s\n", outfile);
    exit(1);
  }

  /* calculate rss using just intercept */
  a = b = 0.0;
  for(i=0; i<n_ind; i++) {
    a += y[i];
    b += (y[i]*y[i]);
  }
  rss0 = (b - a*a/(double)n_ind);

  /* print result: n_terms, rss, bic */
  fprintf(fp, "%d,%lf,%lf\n", 1, rss0,
	  log(rss0) + delta*log((double)n_ind)/(double)n_ind);

  /* loop over # terms added */
  for(i=0; i<max_step; i++) {
    rss_min = rss0*2.0;
    bic_min = log(rss_min) + delta*8*log((double)n_ind)/(double)n_ind;

    printf("%d", i+1);

    /* loop over marginal effects: */
    for(c1=0; c1<n_chr; c1++) {
      for(m1=0; m1<n_mar[c1]; m1++) {
	/* is this one not already used? */
	for(j=0, used=0; j<i; j++) {
	  if((index_c1[j]==c1 && index_m1[j]==m1) ||
	     (index_inter[j]==1 && index_c2[j]==c1 && index_m2[j]==m1))
	    used = 1;
	}

	if(!used) {
	  index_inter[i]=0;
	  index_c1[i]=c1;
	  index_m1[i]=m1;
	  /* create xpx matrix */
	  create_xpx3(n_chr, n_mar, n_ind, i+1,
		      p, q, y, xpx, x, index_inter, index_c1,
		      index_m1, index_c2, index_m2, flag,
		      &n_col);

	  /* sweep columns */
	  for(j=0; j<n_col+1; j++)
	    index_work[j] = j;
	  sweep(xpx, n_col+2, index_work, n_col+1, &err);

	  if(!err) { /* no error in the sweep */
	    rss_cur = xpx[n_col+1][n_col+1];
	    bic_cur = log(rss_cur) + delta*(double)(n_col+1)*
	      log((double)n_ind)/(double)n_ind;

	    /* is this a new min? */
	    if(bic_cur < bic_min) {
	      rss_min = rss_cur;
	      bic_min = bic_cur;
	      keep_inter = 0;
	      keep_c1 = c1;
	      keep_m1 = m1;
	      keep_nterm=n_col+1;
	    }
	  }

	} /* if(not already used) */
      } /* loop markers */
    } /* loop chr */

    printf("."); /* done with marginals */

    /* loop over interactions: */
    for(c1=0; c1<n_chr; c1++) {
      for(m1=0; m1<n_mar[c1]; m1++) {
	for(c2=c1; c2<n_chr; c2++) {
	  for(m2=0; m2<n_mar[c2]; m2++) {

	    if(c1<c2 || m1 < m2) {
	      /* is this one not already used? */
	      for(j=0, used=0; j<i; j++) {
		if(index_inter[j]==1 && index_c1[j]==c1 &&
		   index_m1[j]==m1 && index_c2[j]==c2 && index_m2[j]==m2)
		  used = 1;
	      }

	      if(!used) {
		index_inter[i]=1;
		index_c1[i]=c1;
		index_m1[i]=m1;
		index_c2[i]=c2;
		index_m2[i]=m2;

		/* create xpx matrix */
		create_xpx3(n_chr, n_mar, n_ind, i+1,
			    p, q, y, xpx, x, index_inter, index_c1,
			    index_m1, index_c2, index_m2, flag,
			    &n_col);

		/* sweep columns */
		for(j=0; j<n_col+1; j++)
		  index_work[j] = j;
		sweep(xpx, n_col+2, index_work, n_col+1, &err);

		if(!err) { /* no error in sweep */
		  rss_cur = xpx[n_col+1][n_col+1];
		  bic_cur = log(rss_cur) + delta*(double)(n_col+1)*
		    log((double)n_ind)/(double)n_ind;

		  /* is this a new min? */
		  if(bic_cur < bic_min) {
		    rss_min = rss_cur;
		    bic_min = bic_cur;
		    keep_inter = 1;
		    keep_c1 = c1;
		    keep_m1 = m1;
		    keep_c2 = c2;
		    keep_m2 = m2;
		    keep_nterm=n_col+1;
		  }
		}

	      } /* if(not already used) */

	    } /* c1<c2 and m1<m2 */
	  } /* loop mar 2 */
	} /* loop chr 2 */
      } /* loop mar 1 */
      printf(".");
    } /* loop chr 1 */

    /* print result */
    index_inter[i]=keep_inter;
    index_c1[i]=keep_c1;
    index_m1[i]=keep_m1;
    index_c2[i]=keep_c2;
    index_m2[i]=keep_m2;

    fprintf(fp, "%ld,%lf,%lf", keep_nterm, rss_min, bic_min);
    for(j=0; j<i+1; j++) {
      if(index_inter[j]==0)
	fprintf(fp, ",(%d %d %s)", index_c1[j]+1, index_m1[j]+1,
		marker_names[index_c1[j]][index_m1[j]]);
      else
	fprintf(fp, ",(%d %d %s) x (%d %d %s)", index_c1[j]+1, index_m1[j]+1,
		marker_names[index_c1[j]][index_m1[j]],
		index_c2[j]+1, index_m2[j]+1,
		marker_names[index_c2[j]][index_m2[j]]);
    }
    fprintf(fp, "\n");

  }
  fclose(fp);
}



/**********************************************************************
 * create_xpx3
 *
 * Creates the X and (X y)'(X y) matrices for the set of markers and/or
 * interactions chosen so far
 **********************************************************************/
void create_xpx3(int n_chr, int *n_mar, int n_ind, int cur_step,
		 double ***p, double ***q, double *y, double **xpx,
		 double **x, int *index_inter, int *index_c1,
		 int *index_m1, int *index_c2, int *index_m2,
		 int **flag, int *n_col)
{
  int i, j, k;

  /* clear out flag matrix */
  /* (indicates if marginal effects already used) */

  for(i=0; i<n_chr; i++)
    for(j=0; j<n_mar[i]; j++)
      flag[i][j]=0;

  *n_col = 0;

  /* create X matrix */
  for(i=0; i<cur_step; i++) {

    if(index_inter[i]==0) { /* add marginal effect */
      if(flag[index_c1[i]][index_m1[i]] == 1) {
	/* error */
	printf("!");
      }
      flag[index_c1[i]][index_m1[i]] = 1;

      /* create columns for this locus, starting at n_col */
      for(j=0; j<n_ind; j++) {
	x[j][*n_col] = (p[j][index_c1[i]][index_m1[i]] -
			q[j][index_c1[i]][index_m1[i]]);
	x[j][*n_col+1] = (1.0 - p[j][index_c1[i]][index_m1[i]] -
			  q[j][index_c1[i]][index_m1[i]]);
      }
      (*n_col) += 2;
    }

    else { /* interaction */

      if(!flag[index_c1[i]][index_m1[i]]) { /* marginal 1 not yet added */
	flag[index_c1[i]][index_m1[i]] = 1;
	/* create columns for this locus, starting at n_col */
	for(j=0; j<n_ind; j++) {
	  x[j][*n_col] = (p[j][index_c1[i]][index_m1[i]] -
			  q[j][index_c1[i]][index_m1[i]]);
	  x[j][*n_col+1] = (1.0 - p[j][index_c1[i]][index_m1[i]] -
			    q[j][index_c1[i]][index_m1[i]]);
	}
	(*n_col) += 2;
      }

      if(!flag[index_c2[i]][index_m2[i]]) { /* marginal 2 not yet added */
	flag[index_c2[i]][index_m2[i]] = 1;
	/* create columns for this locus, starting at n_col */
	/* increment n_col by 2 */
	for(j=0; j<n_ind; j++) {
	  x[j][*n_col] = (p[j][index_c2[i]][index_m2[i]] -
			  q[j][index_c2[i]][index_m2[i]]);
	  x[j][*n_col+1] = (1.0 - p[j][index_c2[i]][index_m2[i]] -
			    q[j][index_c2[i]][index_m2[i]]);
	}
	(*n_col) += 2;
      }

      /* create columns for the interaction, starting at n_col */
      /* increment n_col by 4 */
      for(j=0; j<n_ind; j++) {
	x[j][*n_col] = ((p[j][index_c1[i]][index_m1[i]] -
			 q[j][index_c1[i]][index_m1[i]]) *
			(p[j][index_c2[i]][index_m2[i]] -
			 q[j][index_c2[i]][index_m2[i]]));
	x[j][*n_col+1] = ((p[j][index_c1[i]][index_m1[i]] -
			   q[j][index_c1[i]][index_m1[i]]) *
			  (1.0-p[j][index_c2[i]][index_m2[i]] -
			   q[j][index_c2[i]][index_m2[i]]));
	x[j][*n_col+2] = ((1.0-p[j][index_c1[i]][index_m1[i]] -
			   q[j][index_c1[i]][index_m1[i]]) *
			  (p[j][index_c2[i]][index_m2[i]] -
			   q[j][index_c2[i]][index_m2[i]]));
	x[j][*n_col+3] = ((1.0-p[j][index_c1[i]][index_m1[i]] -
			   q[j][index_c1[i]][index_m1[i]]) *
			  (1.0-p[j][index_c2[i]][index_m2[i]] -
			   q[j][index_c2[i]][index_m2[i]]));
      }
      (*n_col) += 4;
    }
  } /* loop cur_step */

  /* create (X y)'(X y) matrix */
  for(i=0; i<*n_col+2; i++)
    for(j=0; j<*n_col+2; j++)
      xpx[i][j] = 0.0;

  xpx[0][0] = (double)n_ind;
  for(i=0; i<n_ind; i++) {
    xpx[0][*n_col+1] = xpx[*n_col+1][0] += y[i];
    xpx[*n_col+1][*n_col+1] += (y[i]*y[i]);

    for(j=0; j<*n_col; j++) {
      xpx[0][j+1] = xpx[j+1][0] += x[i][j];
      xpx[*n_col+1][j+1] = xpx[j+1][*n_col+1] += (x[i][j]*y[i]);
      xpx[j+1][j+1] += (x[i][j]*x[i][j]);

      for(k=j+1; k<*n_col; k++)
	xpx[j+1][k+1] = xpx[k+1][j+1] += (x[i][j]*x[i][k]);
    }
  }

}


/* end of f2_anal.c */
