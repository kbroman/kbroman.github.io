
info713:	data regarding the number of cells per well (n.cell),
		the number of squares counted (n.sq) and the volume
		added per well (vol) for the first LDA for subject 713

p713:		plate data for the first LDA for subject 713
		(consists of twelve 8x12 matrices, with blank lines
		between them)

info713.2:	data regarding the number of cells per well (n.cell),
		the number of squares counted (n.sq) and the volume
		added per well (vol) for the second LDA for subject 713

p713.2:		plate data for the second LDA for subject 713
		(consists of ten 8x12 matrices, with blank lines
		between them)

info711:	data regarding the number of cells per well (n.cell),
		the number of squares counted (n.sq) and the volume
		added per well (vol) for the LDA for subject 711

p711:		plate data for the LDA for subject 711
		(consists of twelve 8x12 matrices, with blank lines
		between them)

